<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://cohhe.com
 * @since             1.0
 * @package           directory_func
 *
 * @wordpress-plugin
 * Plugin Name:       Functionality for Directory theme
 * Plugin URI:        http://cohhe.com/
 * Description:       This plugin contains Directory theme core functionality
 * Version:           1.3.8
 * Author:            Cohhe
 * Author URI:        http://cohhe.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       functionality-for-directory-theme
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-directory-functionality-activator.php
 */
function directory_activate_directory_func() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-directory-functionality-activator.php';
	directory_func_Activator::directory_activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-directory-functionality-deactivator.php
 */
function directory_deactivate_directory_func() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-directory-functionality-deactivator.php';
	directory_func_Deactivator::directory_deactivate();
}

register_activation_hook( __FILE__, 'directory_activate_directory_func' );
register_deactivation_hook( __FILE__, 'directory_deactivate_directory_func' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
define('DIRECTORY_PLUGIN', plugin_dir_path( __FILE__ ));
require plugin_dir_path( __FILE__ ) . 'includes/class-directory-functionality.php';
require plugin_dir_path( __FILE__ ) . 'includes/widgets/widget-social.php';
define('DIRECTORY_PUBLIC', plugin_dir_url( __FILE__ ).'public/');

/**
* Required: 3 step installer
*/
require_once(plugin_dir_path( __FILE__ ) . '/includes/installer/importer/widgets-importer.php');
require_once(plugin_dir_path( __FILE__ ) . '/includes/installer/functions-themeinstall.php');

function dt_setup_plugin() {
	// Extend Visual Composer
	if ( defined('WPB_VC_VERSION') ) {
		vc_map( array(
			"name" => __("Featured listings", "functionality-for-directory-theme" ),
			"base" => "directory_featured_listings",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Title", "functionality-for-directory-theme" ),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Background title", "functionality-for-directory-theme" ),
					"param_name" => "background_title",
					"value" => "",
					"description" => __("Enter the background title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Listing IDs", "functionality-for-directory-theme" ),
					"param_name" => "ids",
					"value" => "",
					"description" => __("Custom listing IDs separated by a comma. Leave blank to select from the featured listings.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Listing limit", "functionality-for-directory-theme" ),
					"param_name" => "limit",
					"value" => '3',
					"description" => __("How many listings to show.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "checkbox",
					"holder" => "div",
					"class" => "",
					"heading" => __("Random order", "functionality-for-directory-theme" ),
					"param_name" => "random",
					"description" => __("Order featured listings randomly", "functionality-for-directory-theme" )
					)
				)
		));

		vc_map( array(
			"name" => __("Popular cities", "functionality-for-directory-theme" ),
			"base" => "directory_popular_cities",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Title", "functionality-for-directory-theme" ),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Background title", "functionality-for-directory-theme" ),
					"param_name" => "background_title",
					"value" => "",
					"description" => __("Enter the background title for this module.", "functionality-for-directory-theme" )
					),
				array(
					'type' => 'param_group',
					'value' => '',
					'param_name' => 'city_group',
					'params' => array(
						array(
							'type' => 'textfield',
							'heading' => __('City name', 'functionality-for-directory-theme'),
							'param_name' => 'city_name',
							'admin_label' => true
						),
						array(
							'type' => 'attach_image',
							'value' => '',
							'heading' => __('City image', 'functionality-for-directory-theme'),
							'param_name' => 'city_image',
						),
						array(
							'type' => 'textfield',
							'heading' => __('External URL', 'functionality-for-directory-theme'),
							'param_name' => 'external_url'
						),
					)
				)
			)
		));

		vc_map( array(
			"name" => __("Quotes", "functionality-for-directory-theme" ),
			"base" => "directory_quotes",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Testimonial category", "functionality-for-directory-theme" ),
					"param_name" => "category",
					"value" => '',
					"description" => __("Category from which to pull your quotes", "functionality-for-directory-theme" )
					),
				array(
					"type" => "checkbox",
					"holder" => "div",
					"class" => "",
					"heading" => __("Autoplay", "functionality-for-directory-theme" ),
					"param_name" => "autoplay",
					"value" => '',
					"description" => __("Do you want quotes to slide automatically?", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Autoplay delay", "functionality-for-directory-theme" ),
					"param_name" => "delay",
					"value" => '',
					"description" => __("Time in ms of how fast to slide the quotes.", "functionality-for-directory-theme" )
					),
				)
		));

		vc_map( array(
			"name" => __("Module title", "functionality-for-directory-theme" ),
			"base" => "directory_title",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Title", "functionality-for-directory-theme" ),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Background title", "functionality-for-directory-theme" ),
					"param_name" => "background_title",
					"value" => "",
					"description" => __("Enter the background title for this module.", "functionality-for-directory-theme" )
					)
				)
		));

		vc_map( array(
			"name" => __("How it works", "functionality-for-directory-theme" ),
			"base" => "directory_how",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Title", "functionality-for-directory-theme" ),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Background title", "functionality-for-directory-theme" ),
					"param_name" => "background_title",
					"value" => "",
					"description" => __("Enter the background title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textarea",
					"holder" => "div",
					"class" => "",
					"heading" => __("Content", "functionality-for-directory-theme" ),
					"param_name" => "how_content",
					"value" => "",
					"description" => __("Provide some content for this module!", "functionality-for-directory-theme" )
					)
				)
		));

		vc_map( array(
			"name" => __("Blog posts", "functionality-for-directory-theme" ),
			"base" => "directory_blog",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Title", "functionality-for-directory-theme" ),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Background title", "functionality-for-directory-theme" ),
					"param_name" => "background_title",
					"value" => "",
					"description" => __("Enter the background title for this module.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Limit", "functionality-for-directory-theme" ),
					"param_name" => "limit",
					"value" => "",
					"description" => __("How much posts to show?", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Categories", "functionality-for-directory-theme" ),
					"param_name" => "categories",
					"value" => "",
					"description" => __("Comma separated blog categories", "functionality-for-directory-theme" )
					)
				)
		));

		vc_map( array(
			"name" => __("Package", "functionality-for-directory-theme" ),
			"base" => "directory_package",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Title", "functionality-for-directory-theme" ),
					"param_name" => "title",
					"value" => "",
					"description" => __("Enter title for this package.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "attach_image",
					"holder" => "div",
					"class" => "",
					"heading" => __("Package image", "functionality-for-directory-theme" ),
					"param_name" => "image",
					"value" => "",
					"description" => __("Provide an image for this package.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Package price", "functionality-for-directory-theme" ),
					"param_name" => "price",
					"value" => "",
					"description" => __("How much does this package cost?", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Small description", "functionality-for-directory-theme" ),
					"param_name" => "description",
					"value" => "",
					"description" => __("Just a small description for this package.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textarea",
					"holder" => "div",
					"class" => "",
					"heading" => __("Package benefits", "functionality-for-directory-theme" ),
					"param_name" => "explanation",
					"value" => "",
					"description" => __("Provide benefits, one benefit per line.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Button text", "functionality-for-directory-theme" ),
					"param_name" => "button_text",
					"value" => "",
					"description" => __("Text for the button.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Button URL", "functionality-for-directory-theme" ),
					"param_name" => "button_url",
					"value" => "",
					"description" => __("Link button to a specific URL.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "checkbox",
					"holder" => "div",
					"class" => "",
					"heading" => __("Popular listing?", "functionality-for-directory-theme" ),
					"param_name" => "popular",
					"value" => '',
					"description" => __("Do you want to show this listing as popular?", "functionality-for-directory-theme" )
					)
				)
		));

		vc_map( array(
			"name" => __("Gallery", "functionality-for-directory-theme" ),
			"base" => "directory_gallery",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "attach_images",
					"holder" => "div",
					"class" => "",
					"heading" => __("Gallery images", "functionality-for-directory-theme" ),
					"param_name" => "media",
					"value" => "",
					"description" => __("Choose your gallery images.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Autoplay", "functionality-for-directory-theme" ),
					"param_name" => "autoplay",
					"value" => "3000",
					"description" => __("Provide a value for autostart in milliseconds.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __("Type", "functionality-for-directory-theme" ),
					"param_name" => "type",
					"value" => array(
						__( "Tiled", "functionality-for-directory-theme" ) => "tiled",
						__( "Slider", "functionality-for-directory-theme" ) => "slider"
					),
					"description" => ''
				)
			)
		));

		vc_map( array(
			"name" => __("Team member", "functionality-for-directory-theme" ),
			"base" => "directory_team_member",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),

			"params" => array(
				array(
					"type" => "attach_image",
					"holder" => "div",
					"class" => "",
					"heading" => __("Picture", "functionality-for-directory-theme" ),
					"param_name" => "image",
					"value" => "",
					"description" => __("Provide a picture for this member.", "functionality-for-directory-theme" )
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Member name", "functionality-for-directory-theme" ),
					"param_name" => "name"
					),
				array(
					"type" => "textarea",
					"holder" => "div",
					"heading" => __("Member description", "functionality-for-directory-theme" ),
					"param_name" => "desc"
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Member position", "functionality-for-directory-theme" ),
					"param_name" => "position"
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Facebook URL", "functionality-for-directory-theme" ),
					"param_name" => "s_facebook"
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Google+ URL", "functionality-for-directory-theme" ),
					"param_name" => "s_gplus"
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("LinkedIn URL", "functionality-for-directory-theme" ),
					"param_name" => "s_linkedin"
					),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Twitter URL", "functionality-for-directory-theme" ),
					"param_name" => "s_twitter"
					),
			)
		));

		vc_map( array(
			"name" => __("Listing categories", "functionality-for-directory-theme" ),
			"base" => "directory_builder_categories",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),
			"params" => array(
				array(
					"type" => "checkbox",
					"holder" => "div",
					"class" => "",
					"heading" => __("Show child categories", "functionality-for-directory-theme" ),
					"param_name" => "childs"
					),
				array(
					"type" => "checkbox",
					"holder" => "div",
					"class" => "",
					"heading" => __("Show listing count", "functionality-for-directory-theme" ),
					"param_name" => "count"
					),
				array(
					"type" => "checkbox",
					"holder" => "div",
					"class" => "",
					"heading" => __("Hide empty listing categories", "functionality-for-directory-theme" ),
					"param_name" => "hide_empty"
					)
			)
		));

		vc_map( array(
			"name" => __("Listing search form", "functionality-for-directory-theme" ),
			"base" => "listing_search",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),
			"params" => array(
				array(
					'type' => 'param_group',
					'param_name' => 'all_active_fields',
					'params' => array(
						array(
							'type' => 'dropdown',
							"heading"     => __( "Search field", "functionality-for-directory-theme" ),
							'param_name' => 'active_field',
							'admin_label' => true,
							'value' => directory_get_searchable_fields()
						)
					)
				)
			)
		));

		vc_map( array(
			"name" => __("Listing by category", "functionality-for-directory-theme" ),
			"base" => "directory_listing_category",
			"class" => "",
			"icon" => "icon-wpb-ui-gap-content",
			"category" => __( "by Whitelab theme", "functionality-for-directory-theme" ),
			"params" => array(
				array(
					'type' => 'param_group',
					'param_name' => 'categories',
					'params' => array(
						array(
							'type' => 'dropdown',
							"heading"     => __( "Category to show", "functionality-for-directory-theme" ),
							'param_name' => 'active_field',
							'admin_label' => true,
							'value' => directory_get_active_listing_categories()
						)
					)
				),
				array(
					"type" => "textfield",
					"holder" => "div",
					"heading" => __("Listings per page", "functionality-for-directory-theme" ),
					"param_name" => "per_page",
					"value" => "9"
				)
			)
		));
	}
}
add_action('after_setup_theme', 'dt_setup_plugin');

function directory_get_searchable_fields() {
	global $wpdb;
	$main_settings = get_option( 'db_main_settings' );
	$field_list = $wpdb->get_results('SELECT * FROM '.$wpdb->prefix.'directory_fields WHERE field_active="yes" ORDER BY field_order DESC');
	$field_data_list = array(
		'Listing name' => 'listing_name',
		'Search radius' => 'search_radius',
		'Listing categories' => 'listing_categories',
		'Keyword' => 'listing_keyword'
	);
	if ( !empty($field_list) ) {
		foreach ($field_list as $field_value) {
			$field_settings = json_decode($field_value->field_settings, true);
			if ( $field_settings['field_type'] != 'fileupload' && $field_settings['field_type'] != 'html' && $field_settings['field_type'] != 'checkbox' && $field_settings['field_type'] != 'radio' && $field_settings['field_type'] != 'hoursofoperation' ) {
				$field_data_list[$field_settings['frontend_title']] = $field_settings['field_name'];
			}
		}
	}

	return $field_data_list;
}

function directory_get_active_listing_categories() {
	global $wpdb;
	$category_list = $wpdb->get_results('SELECT terms.term_id, terms.name FROM '.$wpdb->term_taxonomy.' as term_taxonomy, '.$wpdb->terms.' as terms WHERE term_taxonomy.taxonomy="listing_category" && term_taxonomy.term_taxonomy_id=terms.term_id');

	$active_categories = array();
	if ( !empty($category_list) ) {
		foreach ($category_list as $category_data) {
			$active_categories[htmlspecialchars_decode($category_data->name)] = $category_data->term_id;
		}
	}

	return $active_categories;
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_directory_func() {

	$plugin = new directory_func();
	$plugin->directory_run();

}
run_directory_func();

function df_register_image_size() {
	add_image_size( 'db_blog_image', 0, 400 );
}
add_action( 'init', 'df_register_image_size' );

function directory_featured_listings_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
		'background_title' => '',
		'ids' => '',
		'limit' => '3',
		'type' => 'sticky',
		'random' => ''
	), $atts ) );
	$output = '';

	global $wpdb;
	if ( $ids == '' ) {
		$sticky_listings = get_option('db_sticky_listings', array());
	} else {
		$sticky_listings = explode(',', $ids);
	}

	if ( $type == 'sticky' ) {
		if ( $sticky_listings != '' && !empty($sticky_listings) ) {
			if ( defined('ICL_LANGUAGE_CODE') ) {
				if ( !empty($sticky_listings) ) {
					$search_lang_listings = $wpdb->get_results('SELECT element_id, language_code FROM '.$wpdb->prefix.'icl_translations WHERE element_id IN('.implode(',', $sticky_listings).') GROUP BY element_id');
					if ( !empty($search_lang_listings) ) {
						foreach ($search_lang_listings as $listing_lang_data) {
							if ( in_array($listing_lang_data->element_id, $sticky_listings) && ICL_LANGUAGE_CODE != $listing_lang_data->language_code ) {
								unset($sticky_listings[array_search($listing_lang_data->element_id, $sticky_listings)]);
							}
						}
					}
				}
			}
			$search_listings = $wpdb->get_results('SELECT * FROM '.$wpdb->posts.' WHERE post_type="listings" && post_status="publish" && ID IN('.implode(',', $sticky_listings).')'.($random=='true'?' ORDER BY RAND()':'').' LIMIT '.intval($limit));
		} else {
			$search_listings = array();
		}
	} else {
		$search_listings = $wpdb->get_results('SELECT * FROM '.$wpdb->posts.' as posts, '.$wpdb->postmeta.' as meta WHERE posts.post_type="listings" && posts.post_status="publish" && meta.meta_key="directory_post_likes" && meta.meta_value LIKE "%i:'.get_current_user_id().';%" && meta.post_id=posts.ID LIMIT '.$limit);
	}

	if ( $title != '' ) {
		$output .= '<div class="dt-module-title">';
			$output .= '<span class="dt-module-background-title">'.$background_title.'</span>';
			$output .= '<span class="dt-module-front-title">'.$title.'</span>';
		$output .= '</div>';
	}

	if ( !empty($search_listings) ) {

		wp_enqueue_script( 'jquery.mo' );

		$output .= '<div class="dt-featured-listings">';
		$listings_loop = 1;
		foreach ($search_listings as $listing_value) {
			$listing_order_info = get_post_meta($listing_value->ID, 'db_order_info', true);
			if ( isset($listing_order_info['listing_expires']) && is_numeric($listing_order_info['listing_expires']) && $listing_order_info['listing_expires'] < time() ) {
				wp_update_post( array( 'ID' => $listing_value->ID, 'post_status' => 'pending' ) );
				continue;
			}

			$listing_ratings = get_post_meta( $listing_value->ID, 'directory_post_likes', true);
			if ( $listing_ratings != '' ) {
				$liked = $listing_ratings;
			} else {
				$liked = array();
			}

			if ( $type == 'favorites' && !isset($liked[get_current_user_id()]) ) {
				continue;
			}

			$output .= directory_get_single_listing_item( $listing_value );

			if ( $type == 'favorites' && $limit == $listings_loop ) {
				break;
			}
			$listings_loop++;

			$listing_custom_fields = array();
		}
		$output .= '<div class="clearfix"></div></div>';
	}

	return $output;
}
add_shortcode('directory_featured_listings','directory_featured_listings_func');

function directory_listing_category_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'categories' => '',
		'per_page' => '9'
	), $atts ) );
	$output = '';

	$selected_categories = vc_param_group_parse_atts( $categories );

	$active_categories = array();
	if ( !empty($selected_categories) ) {
		foreach ($selected_categories as $cat_data) {
			$active_categories[] = $cat_data['active_field'];
		}
	}

	if ( !empty($active_categories) ) {
		wp_enqueue_script( 'jquery.mo' );

		global $wpdb;
		$sticky_listings = get_option('db_sticky_listings', array());

		if ( !isset( $_GET['db-page'] ) || intval( $_GET['db-page'] ) == 1 ) {
			$per_page_limit = $per_page;
		} else {
			$per_page_limit = (intval( $_GET['db-page'] )-1)*$per_page . ', ' . $per_page;
		}

		$search_listings = $wpdb->get_results('SELECT posts.ID, posts.post_title, posts.post_content, posts.post_excerpt FROM '.$wpdb->posts.' as posts, '.$wpdb->term_relationships.' as terms WHERE posts.post_type="listings" && posts.post_status="publish" && terms.object_id=posts.ID && terms.term_taxonomy_id IN ('.implode(',', $active_categories).')'.(!empty($sticky_listings)?' ORDER BY FIELD(posts.ID, '.implode(',', $sticky_listings).') desc':'').' LIMIT '.$per_page_limit);

		if ( !empty($search_listings) ) {
			foreach ($search_listings as $listing_data) {
				$output .= directory_get_single_listing_item( $listing_data );
			}

			$total_listings = $wpdb->get_results('SELECT count(posts.ID) as count FROM '.$wpdb->posts.' as posts, '.$wpdb->term_relationships.' as terms WHERE posts.post_type="listings" && posts.post_status="publish" && terms.object_id=posts.ID && terms.term_taxonomy_id IN ('.implode(',', $active_categories).')');
			$total_pages = $total_listings['0']->count/$per_page;

			$output .= '<div class="clearfix"></div><div class="navigation paging-navigation">' . paginate_links( array(
				'format' => '?db-page=%#%',
				'total' => ( is_float( $total_pages ) ? ceil( $total_pages ) : round( $total_pages ) ),
				'current' => ( isset( $_GET['db-page'] ) ? intval( $_GET['db-page'] ) : 1 ),
				'prev_text' => '',
				'next_text' => '',
			) ) . '</div>';
		}
	} else {
		esc_html_e('There\'s no category selected!');
	}

	return $output;
}
add_shortcode('directory_listing_category','directory_listing_category_func');

function directory_get_single_listing_item( $listing_value ) {
	$main_settings = get_option( 'db_main_settings' );

	$listing_custom_fields = db_get_listing_custom_fields( $listing_value->ID, 'on_listing' );

	$listing_category = get_the_terms($listing_value->ID, 'listing_category');
	$img = wp_get_attachment_image_src( get_post_thumbnail_id($listing_value->ID), 'db_single_listing' );

	$listing_ratings = get_post_meta( $listing_value->ID, 'directory_post_likes', true);
	if ( $listing_ratings != '' ) {
		$liked = $listing_ratings;
	} else {
		$liked = array();
	}

	$sticky_listings = get_option('db_sticky_listings', array());

	$output = '<div class="dt-featured-listings-item">';
		$output .= '<div class="dt-featured-listings-item-inner">';
			$output .= '<div class="dt-featured-listings-image">';
				$output .= '<a href="'.get_permalink($listing_value->ID).'" class="dt-featured-item-image" '.(isset($img['0'])?'style="background: url('.$img['0'].')"':'').'></a>';
				$output .= '<div class="dt-featured-image-overlay"></div>';

				if ( in_array($listing_value->ID, $sticky_listings) ) {
					$output .= '<span class="dt-featured-listings-image-note">'.__('Featured', 'functionality-for-directory-theme').'</span>';
				}

				$output .= '
				<span class="dt-listing-likes'.(isset($liked[get_current_user_id()])?' liked':(!is_user_logged_in()?' not-logged-in':'')).'" data-id="'.$listing_value->ID.'">
					<div class="db-favorite-tooltip">
						' . sprintf( __( 'You have to be logged in to favorite, click %s to login', 'whitelab' ), '<a href="javascript:void(0)">'.__( 'here', 'whitelab' ).'</a>' ) . '
					</div>
					<svg class="like-thumb" version="1.1" width="20" height="20"><path d="M18.9,10.5C19.3,10 19.6,9.4 19.6,8.7C19.6,8.1 19.3,7.5 18.9,7C18.4,6.6 17.9,6.3 17.2,6.3L13.8,6.3C13.9,6.2 13.9,6.1 13.9,6C14,6 14,5.9 14.1,5.8C14.1,5.7 14.2,5.6 14.2,5.5C14.3,5.3 14.4,5 14.5,4.8C14.6,4.7 14.7,4.4 14.8,4.1C14.8,3.8 14.9,3.5 14.9,3.2C14.9,3 14.9,2.8 14.9,2.7C14.9,2.6 14.8,2.4 14.8,2.1C14.8,1.9 14.7,1.7 14.7,1.5C14.6,1.3 14.5,1.2 14.4,1C14.2,0.8 14.1,0.6 13.9,0.5C13.7,0.3 13.4,0.2 13.1,0.1C12.8,0 12.5,0 12.1,0C11.9,0 11.7,0.1 11.6,0.2C11.4,0.4 11.3,0.6 11.2,0.9C11.1,1.1 11,1.3 10.9,1.5C10.9,1.7 10.8,1.9 10.8,2.3C10.7,2.6 10.6,2.9 10.6,3C10.6,3.2 10.5,3.4 10.4,3.6C10.3,3.8 10.2,4 10,4.2C9.7,4.5 9.3,5 8.8,5.7C8.4,6.2 8,6.7 7.5,7.2C7.1,7.6 6.8,7.9 6.6,7.9C6.4,7.9 6.2,8 6.1,8.2C5.9,8.3 5.9,8.5 5.9,8.7L5.9,16.6C5.9,16.8 5.9,17 6.1,17.2C6.3,17.3 6.4,17.4 6.7,17.4C6.9,17.4 7.6,17.6 8.6,17.9C9.2,18.2 9.7,18.3 10.1,18.4C10.4,18.5 10.9,18.7 11.5,18.8C12.2,18.9 12.8,19 13.3,19L13.5,19L14.4,19L14.9,19C16,19 16.8,18.6 17.3,18C17.8,17.5 18,16.7 17.9,15.8C18.2,15.5 18.4,15.1 18.6,14.6C18.7,14.1 18.7,13.6 18.6,13.2C18.9,12.7 19.1,12.1 19.1,11.5C19.1,11.2 19,10.9 18.9,10.5L18.9,10.5z" fill="#ffffff" stroke="none" stroke-width="0" fill-opacity="1" stroke-opacity="0"></path><path d="M4.3,7.9L0.8,7.9C0.6,7.9 0.4,8 0.2,8.1C0.1,8.3 0,8.5 0,8.7L0,16.6C0,16.8 0.1,17 0.2,17.2C0.4,17.3 0.6,17.4 0.8,17.4L4.3,17.4C4.5,17.4 4.7,17.3 4.9,17.2C5,17 5.1,16.8 5.1,16.6L5.1,8.7C5.1,8.5 5,8.3 4.9,8.1C4.7,8 4.5,7.9 4.3,7.9L4.3,7.9M2.9,15.6C2.7,15.7 2.6,15.8 2.3,15.8C2.1,15.8 1.9,15.7 1.8,15.6C1.6,15.4 1.6,15.3 1.6,15C1.6,14.8 1.6,14.6 1.8,14.5C1.9,14.3 2.1,14.2 2.3,14.2C2.6,14.2 2.7,14.3 2.9,14.5C3.1,14.6 3.1,14.8 3.1,15C3.1,15.3 3.1,15.4 2.9,15.6L2.9,15.6z" fill="#ffffff" stroke="none" stroke-width="0" fill-opacity="1" stroke-opacity="0"></path></svg>
					<svg class="like-thumb-liked" width="21px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(-1250.000000, -1146.000000)" stroke="#FFFFFF" fill="#247BA0"><g transform="translate(150.000000, 1091.000000)"><g transform="translate(780.000000, 39.000000)"><g transform="translate(319.322034, 16.000000)"><g transform="translate(0.677966, 0.000000)"><g><path d="M18.8951038,10.546385 C19.3435043,10.0274556 19.5677902,9.41378588 19.5677902,8.70524601 C19.5677902,8.06270843 19.3351085,7.50673121 18.8713302,7.03692483 C18.4066094,6.56716173 17.8563464,6.33241002 17.2204127,6.33241002 L13.8329071,6.33241002 C13.865462,6.21711162 13.8981025,6.11825968 13.9306574,6.03589749 C13.9629124,5.95353531 14.0082322,5.86282005 14.0650747,5.76396811 C14.1219601,5.66507289 14.1628678,5.59089066 14.1872412,5.54155125 C14.3339523,5.26161503 14.4462666,5.03080182 14.5237986,4.84971754 C14.601202,4.66828702 14.6782628,4.42124374 14.7559662,4.10819818 C14.833541,3.79532574 14.8720928,3.48215034 14.8720928,3.16910478 C14.8720928,2.97148747 14.8697369,2.81070159 14.8658817,2.68722323 C14.8620694,2.56365831 14.8412942,2.37824601 14.804927,2.13107289 C14.7680029,1.88402961 14.7189993,1.67805923 14.6580017,1.51337813 C14.5967472,1.34865376 14.4988255,1.1631549 14.3645367,0.957357631 C14.229948,0.751170843 14.0669595,0.584585421 13.8751856,0.456822323 C13.6834545,0.329145786 13.4389503,0.222070615 13.1413731,0.135640091 C12.8434961,0.0491230068 12.507367,0.00588610478 12.1320865,0.00588610478 C11.9201371,0.00588610478 11.7368446,0.0841799544 11.5817807,0.240724374 C11.4187493,0.405448747 11.2799199,0.611375854 11.1658922,0.858419134 C11.0516931,1.10559226 10.9721479,1.31978588 10.9272564,1.50108656 C10.8824078,1.68230068 10.8313909,1.9336287 10.7745484,2.25481093 C10.7009144,2.60096583 10.646128,2.85 10.6092039,3.00238952 C10.5725797,3.15477904 10.5010446,3.35451708 10.3951556,3.60160364 C10.2890525,3.84886333 10.1628167,4.04643736 10.0160199,4.19480182 C9.74701386,4.46660137 9.33532325,4.96090433 8.78077674,5.67753759 C8.38116571,6.20469021 7.9694751,6.7030615 7.54553359,7.17265148 C7.1215064,7.64232802 6.81172111,7.88530296 6.61609204,7.90179271 C6.41240992,7.91823918 6.23708481,8.00267882 6.09028804,8.1551549 C5.94349128,8.30754442 5.87011432,8.48676765 5.87011432,8.69265148 L5.87011432,16.6133576 C5.87011432,16.8275513 5.9475178,17.0107563 6.10245329,17.1631458 C6.2573031,17.3157084 6.44076693,17.3959932 6.6527591,17.4042597 C6.93808541,17.4125262 7.58220065,17.5935672 8.58510483,17.9481185 C9.21281414,18.1619658 9.70396433,18.3249157 10.0586411,18.4359727 C10.4132321,18.5470296 10.90888,18.6665695 11.5443426,18.7944191 C12.1804047,18.9220524 12.7673348,18.9860638 13.305304,18.9860638 L13.5132697,18.9860638 L14.4427969,18.9860638 L14.882973,18.9860638 C15.9676071,18.9696173 16.7703416,18.6482187 17.2923333,18.0223007 C17.7650643,17.4538155 17.9647198,16.7082711 17.8915999,15.7856241 C18.2095239,15.4808451 18.4298261,15.0938337 18.5519497,14.6241572 C18.6903508,14.1219339 18.6903508,13.6399658 18.5519497,13.1787289 C18.9269304,12.6762027 19.1022556,12.1119157 19.0776252,11.4858246 C19.0786533,11.2219453 19.0176557,10.9089863 18.8951038,10.546385 L18.8951038,10.546385 Z"></path><path d="M4.30495325,7.91438724 L0.782858962,7.91438724 C0.57073828,7.91438724 0.387274451,7.99268109 0.232381805,8.14922551 C0.0774891585,8.30568337 0,8.49105239 0,8.70524601 L0,16.6139203 C0,16.8278109 0.0774891585,17.0132665 0.23242464,17.1699408 C0.387445793,17.3262255 0.570909621,17.4045626 0.782901797,17.4045626 L4.30495325,17.4045626 C4.51690259,17.4045626 4.70028075,17.3262255 4.85525907,17.1699408 C5.01015171,17.0132665 5.08759804,16.8278542 5.08759804,16.6139203 L5.08759804,8.70524601 C5.08759804,8.49105239 5.01010888,8.30572665 4.85525907,8.14922551 C4.70032359,7.99263781 4.51694543,7.91438724 4.30495325,7.91438724 L4.30495325,7.91438724 Z M2.89845435,15.5941959 C2.7435617,15.7465854 2.56014071,15.8227585 2.34814853,15.8227585 C2.1279748,15.8227585 1.94245488,15.7465854 1.79171726,15.5941959 C1.64089397,15.4418064 1.56550375,15.2544465 1.56550375,15.0319863 C1.56550375,14.817836 1.64085114,14.6324237 1.79171726,14.4759658 C1.94249771,14.3194214 2.1279748,14.241041 2.34814853,14.241041 C2.56014071,14.241041 2.7435617,14.3194214 2.89845435,14.4759658 C3.05338983,14.6323804 3.13087899,14.8177927 3.13087899,15.0319863 C3.13087899,15.2544465 3.05356117,15.4417631 2.89845435,15.5941959 L2.89845435,15.5941959 Z"></path></g></g></g></g></g></g></g></svg>
				</span>';
				$output .= '<div class="dt-featured-listings-image-meta">';
					if ( isset($listing_custom_fields) && !empty($listing_custom_fields) ) {
						$output .= '<span class="dt-featured-listings-custom-fields">';

						foreach ($listing_custom_fields as $field_data) {
							if ( !empty($field_data['value']) ) {
								$field_value = (is_array($field_data['value'])?implode(', ', $field_data['value']):$field_data['value']);
								if ( $field_data['icon'] == '' ) {
									$output .= '<span class="dt-featured"><span class="db-field-title">' . $field_data['title'] . ': </span><span class="db-field-value">'.$field_value.'</span></span>';
								} else {
									$output .= '<span class="dt-featured"><span class="db-listing-icon '.$field_data['icon'].'" title="'.$field_data['title'].'"></span>'.$field_value.'</span>';
								}
							}
						}
							
						$output .= '</span>';
					}
					
				$output .= '</div>';
			$output .= '</div>';
			$output .= '<div class="dt-featured-listings-data">';
				$output .= '<a href="'.get_permalink($listing_value->ID).'" class="dt-featured-listings-title">'.$listing_value->post_title.'</a>';
				$output .= '<p class="dt-featured-listings-description">'.($listing_value->post_excerpt!=''?$listing_value->post_excerpt:strip_shortcodes(strip_tags($listing_value->post_content))).'</p>';
				$output .= '<div class="dt-featured-listings-meta clearfix">';
					if ( isset($listing_category['0']) ) {
						$cat_meta = get_option( "listing_category_".$listing_category['0']->term_id);
						$tag_color = (isset($cat_meta['tag-category-color'])&&$cat_meta['tag-category-color']!=''?$cat_meta['tag-category-color']:'#2698d7');
						$output .= '
						<a href="'.get_permalink($main_settings['search_page_id']).'?search_category='.$listing_category['0']->term_id.'" class="dt-featured-listings-category '.$listing_category['0']->slug.'" style="color: '.$tag_color.'">'.$listing_category['0']->name.'</a>';
						$custom_style = '.dt-featured-listings-category.'.$listing_category['0']->slug.':before { border-color: '.$tag_color.'; }';
					}
					$ratings = get_post_meta( $listing_value->ID, 'listing_ratings', true);
					

					if ( $ratings == '' ) {
						$rating_stars = '<img src="'.DIRECTORY_PUBLIC.'images/star-empty.svg" alt=""><img src="'.DIRECTORY_PUBLIC.'images/star-empty.svg" alt=""><img src="'.DIRECTORY_PUBLIC.'images/star-empty.svg" alt=""><img src="'.DIRECTORY_PUBLIC.'images/star-empty.svg" alt=""><img src="'.DIRECTORY_PUBLIC.'images/star-empty.svg" alt="">';
						$listing_rating = 0;
					} else {
						$listing_rating = 0;
						$valid_ratings = 0;
						foreach ($ratings as $rating_value) {
							if ( $rating_value != null ) {
								$listing_rating += $rating_value;
								$valid_ratings++;
							}
						}

						if ($valid_ratings != 0) {
							$listing_rating = round(($listing_rating/$valid_ratings), 0, PHP_ROUND_HALF_DOWN);
						}
						
						$rating_stars = '';
						for ($i=0; $i < $listing_rating; $i++) { 
							$rating_stars .= '<img src="'.DIRECTORY_PUBLIC.'images/star-colored.svg" alt="">';
						}
						if ( $listing_rating < 5 ) {
							for ($i=0; $i < 5-$listing_rating; $i++) { 
								$rating_stars .= '<img src="'.DIRECTORY_PUBLIC.'images/star-empty.svg" alt="">';
							}
						}
					}

					if ( !isset($_COOKIE['dt-data']) ) {
						$can_rate = true;
					} else {
						$rated_listings = json_decode(stripslashes($_COOKIE['dt-data']));
						if ( !in_array($listing_value->ID, $rated_listings) ) {
							$can_rate = true;
						} else {
							$can_rate = false;
						}
					}

					$output .= '<span class="dt-featured-listings-rating'.(!$can_rate?' rated':'').'" data-original="'.$listing_rating.'" data-id="'.$listing_value->ID.'">'.$rating_stars.'</span>';
				$output .= '</div>';
			$output .= '</div>';
		$output .= '</div><style type="text/css">'.$custom_style.'</style>';
	$output .= '</div>';

	return $output;
}

function directory_popular_cities_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
		'background_title' => '',
		'city_group' => '',
		'cities' => ''
	), $atts ) );
	$output = '';

	if ( $city_group == '' && $cities != '' ) {
		$parsed_cities = explode( '<br />', trim(preg_replace('/\n/', '', nl2br( $cities ))) );
		$new_values = array();

		if ( !empty($parsed_cities) ) {
			foreach ($parsed_cities as $city_data) {
				if ( $city_data != '' ) {
					$parsed_data = explode(':', $city_data);

					$new_values[] = array( 'city_name' => $parsed_data['0'], 'city_image' => $parsed_data['1'] );
				}
			}
		}
	}

	$city_group = vc_param_group_parse_atts( $city_group );

	if ( is_null( $city_group ) && isset( $new_values ) ) {
		$city_group = $new_values;
	} else if ( is_null( $city_group ) ) {
		$city_group = array();
	}

	$output .= '<div class="dt-module-title">';
		if ( $title != '' ) {
			$output .= '<span class="dt-module-background-title">'.$background_title.'</span>';
			$output .= '<span class="dt-module-front-title">'.$title.'</span>';
		}
	$output .= '</div>';

	if ( !empty($city_group) ) {
		$main_settings = get_option( 'db_main_settings' );

		$output .= '<div class="dt-popular-cities clearfix">';
			foreach ($city_group as $city_data) {
				if ( !isset($city_data['city_name']) ) {
					continue;
				}

				if ( isset($city_data['city_image']) ) {
					$img = wp_get_attachment_image_src($city_data['city_image'], 'medium');
				}

				if ( !isset( $city_data['external_url'] ) ) {
					$city_url = add_query_arg('listing_address', $city_data['city_name'], get_permalink($main_settings['search_page_id']));
				} else {
					$city_url = esc_url( $city_data['external_url'] );
				}

				$output .= '
				<a href="'.$city_url.'" class="dt-popular-city-item">
					<div class="dt-popular-city-container" '.(isset($city_data['city_image'])&&isset($img['0'])?'style="background: url('.$img['0'].')"':'').'>
						<div class="dt-popular-city-inner">
							<img src="'.DIRECTORY_PUBLIC.'images/next.svg" alt="">
							<span class="dt-popular-city-name">'.$city_data['city_name'].'</span>
						</div>
					</div>
				</a>';
			}
		$output .= '</div>';
	}

	return $output;
}
add_shortcode('directory_popular_cities','directory_popular_cities_func');

function dt_rate_listing() {
	$listing_id = ( isset($_POST['listing_id']) ? $_POST['listing_id'] : '' );
	$listing_rating = ( isset($_POST['listing_rating']) ? $_POST['listing_rating'] : '' );

	if ( is_user_logged_in() ) {
		$user_id = get_current_user_id();
	} else {
		$user_id = 'anon-'.rand(100000,999999);
	}

	$listing_ratings = get_post_meta( $listing_id, 'listing_ratings', true);

	if ( !isset($_COOKIE['dt-data']) ) {
		setcookie("dt-data", json_encode(array($listing_id)), time() + (86400 * 365), "/");

		if ( $listing_ratings == '' ) {
			$rating = update_post_meta( $listing_id, 'listing_ratings', array( $user_id => $listing_rating ) );
		} else {
			$listing_ratings[$user_id] = $listing_rating;
			$rating = update_post_meta( $listing_id, 'listing_ratings', $listing_ratings );
		}
	} else {
		$rated_listings = json_decode(stripslashes($_COOKIE['dt-data']));
		if ( !in_array($listing_id, $rated_listings) ) {
			$rated_listings[] = $listing_id;
			setcookie("dt-data", json_encode($rated_listings), time() + (86400 * 365), "/");

			if ( $listing_ratings == '' ) {
				$rating = update_post_meta( $listing_id, 'listing_ratings', array( $user_id => $listing_rating ) );
			} else {
				$listing_ratings[$user_id] = $listing_rating;
				$rating = update_post_meta( $listing_id, 'listing_ratings', $listing_ratings );
			}
		} else {
			$rating = false;
		}
	}
	
	if ( $rating ) {
		echo '{"save_response": "0"}';
	} else {
		echo '{"save_response": "failed"}';
	}

	die(0);
}
add_action( 'wp_ajax_dt_rate_listing', 'dt_rate_listing' );
add_action( 'wp_ajax_nopriv_dt_rate_listing', 'dt_rate_listing' );

function directory_quotes_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'category' => '',
		'autoplay' => 'true',
		'delay' => '5000'
	), $atts ) );
	$output = '';

	if ( $category != '' ) {
		$quote_count = array();
		query_posts(array(
			'post_type' => 'testimonial',
			'posts_per_page' => '-1',
			'easy-testimonial-category' => $category,
			'post_status' => 'publish'

		));

		if ( !have_posts() ) {
			wp_reset_query();
			wp_reset_postdata();
			return;
		}

		$output .= '<div class="dt-quotes-wrapper"><img src="'.DIRECTORY_PUBLIC.'images/quote.png" alt=""><div class="dt-quotes-items">';
		while( have_posts() ) {
			the_post();

			$output .= '<div class="dt-quote-item'.(count($quote_count)==1?' active':'').'">'.get_the_content().'</div>';

			$quote_count[] = get_the_ID();
		}
		$output .= '</div>';

		$pagination_random = rand(100000, 999999);

		$output .= '<div class="dt-quote-pagination dt-quote-'.$pagination_random.'">';
			for ($i=0; $i < count($quote_count); $i++) {
				$img = wp_get_attachment_image_src(get_post_thumbnail_id($quote_count[$i]), 'full');
				$output .= '
				<a href="javascript:void(0)" class="dt-quote-page'.($i==1?' active':'').'">';
					if ( isset($img['0']) ) {
						$output .= '<img src="'.$img['0'].'" alt="">';
					}
					$output .= '
					<div class="dt-quote-page-side">';
						$quote_author = get_post_meta($quote_count[$i], '_ikcf_client', true);
						if ( $quote_author ) {
							$output .= '<span class="dt-quote-author">'.$quote_author.'</span>';
						}
						$quote_author_position = get_post_meta($quote_count[$i], '_ikcf_position', true);
						if ( $quote_author_position ) {
							$output .= '<span class="dt-quote-author-position">'.$quote_author_position.'</span>';
						}
					$output .= '
					</div>
				</a>';
			}
		$output .= '</div>';

		if ( $autoplay == 'true' && count($quote_count) > 1 ) {
			$output .= '
			<script type="text/javascript">
			jQuery(document).ready(function($) {
				var $quote_interval;
				dt_scroll_items();

				jQuery(document).on("click", ".dt-quote-pagination a:not(.active)", function() {
					jQuery(".dt-quote-pagination a").removeClass("active");
					jQuery(this).addClass("active");
					clearInterval($quote_interval);
					dt_scroll_items();

					jQuery(".dt-quotes-items .dt-quote-item").removeClass("active");
					jQuery(jQuery(".dt-quotes-items .dt-quote-item").get(jQuery(this).index())).addClass("active");
				});

				jQuery(document).on("wlclick", ".dt-quote-pagination a:not(.active)", function() {
					jQuery(".dt-quote-pagination a").removeClass("active");
					jQuery(this).addClass("active");

					jQuery(".dt-quotes-items .dt-quote-item").removeClass("active");
					jQuery(jQuery(".dt-quotes-items .dt-quote-item").get(jQuery(this).index())).addClass("active");
				});

				function dt_scroll_items() {
					$quote_interval = setInterval(function() {
						if ( jQuery(".dt-quote-'.$pagination_random.' .dt-quote-page.active").next().length ) {
							jQuery(".dt-quote-'.$pagination_random.' .dt-quote-page.active").next().trigger("wlclick");
						} else {
							jQuery(".dt-quote-pagination.dt-quote-'.$pagination_random.' .dt-quote-page").first().trigger("wlclick");
						}
					}, '.$delay.');
				}
			});
			</script>';
		}

		$output .= '</div>';

		wp_reset_query();
		wp_reset_postdata();

	}

	return $output;
}
add_shortcode('directory_quotes','directory_quotes_func');

function directory_title_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
		'background_title' => '',
		'content' => ''
	), $atts ) );
	$output = '';
	
	$output .= '<div class="dt-module-title">';
		if ( $title != '' ) {
			$output .= '<span class="dt-module-background-title">'.$background_title.'</span>';
			$output .= '<span class="dt-module-front-title">'.$title.'</span>';
		}
	$output .= '</div>';

	return $output;
}
add_shortcode('directory_title','directory_title_func');

function directory_how_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
		'background_title' => '',
		'how_content' => ''
	), $atts ) );
	$output = '';
	
	$output .= '<div class="dt-how-wrapper">';
		if ( $title != '' ) {
			$output .= '<div class="dt-how-title-wrapper">';
				$output .= '<span class="dt-how-background-title">'.$background_title.'</span>';
				$output .= '<span class="dt-how-front-title">'.$title.'</span>';
			$output .= '</div>';
		}
		$output .= '<p class="dt-how-content">'.$how_content.'</p>';
	$output .= '</div>';

	return $output;
}
add_shortcode('directory_how','directory_how_func');

function directory_blog_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
		'background_title' => '',
		'limit' => '-1',
		'categories' => '',
		'tags' => '',
		'exclude' => ''
	), $atts ) );
	$output = '';
	
	$output .= '<div class="dt-module-title">';
		if ( $title != '' ) {
			$output .= '<span class="dt-module-background-title">'.$background_title.'</span>';
			$output .= '<span class="dt-module-front-title">'.$title.'</span>';
		}
	$output .= '</div>';

	$post_query = array(
		'post_type' => 'post',
		'posts_per_page' => $limit,
		'ignore_sticky_posts' => 1
	);

	if ( $categories ) {
		$post_query['category_name'] = $categories;
	}
	if ( $tags ) {
		$post_query['tag__in'] = explode(',', $tags);
	}
	if ( $exclude ) {
		$post_query['post__not_in'] = explode(',', $exclude);
	}

	query_posts($post_query);

	if ( !have_posts() ) {
		wp_reset_query();
		wp_reset_postdata();
		return;
	}

	$date_format = get_option('date_format').' '.get_option('time_format');

	$icons = array(
			'facebook'  => '<svg width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-925.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g><g><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M14.2984657,11.1361732 L12.4365846,11.1375471 L12.4351831,17.8200754 L9.88024717,17.8200754 L9.88024717,11.1375929 L8.17603779,11.1375929 L8.17603779,8.8348852 L9.88024717,8.83351129 L9.8773974,7.47751453 C9.8773974,5.59806061 10.3971768,4.45506465 12.6538679,4.45506465 L14.5342024,4.45506465 L14.5342024,6.75914629 L13.3582751,6.75914629 C12.479191,6.75914629 12.4365846,7.08073126 12.4365846,7.68076062 L12.4337348,8.83351129 L14.5469563,8.83351129 L14.2984657,11.1361732 L14.2984657,11.1361732 Z"></path></g></g></g></g></g></g></svg>',
			'gplus'  => '<svg width="24px" height="23px" viewBox="0 0 24 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-958.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g transform="translate(33.416185, 0.696970)"><g><g><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M8.19164145,18.6317775 C5.67650891,18.6317775 3.5547381,17.6280037 3.5547381,16.0242006 C3.5547381,14.3967206 5.49043292,12.8249294 8.00561218,12.8263033 L8.79098085,12.8193422 C8.44727987,12.49217 8.17463627,12.0898453 8.17463627,11.5928129 C8.17463627,11.2976527 8.27120143,11.0150408 8.40472018,10.7630669 L7.98575723,10.7769891 C5.91939343,10.7769891 4.5361336,9.33608512 4.5361336,7.54987344 C4.5361336,5.8026806 6.44627392,4.29491332 8.4771791,4.29491332 L13.0075664,4.29491332 L11.9907123,5.01328156 L10.5548953,5.01328156 C11.5078398,5.37246568 12.0148653,6.46114666 12.0148653,7.57771788 C12.0148653,8.51467413 11.485135,9.3221629 10.7366732,9.89572173 C10.0052633,10.456778 9.86753999,10.6906622 9.86753999,11.1668113 C9.86753999,11.5733493 10.6515071,12.2638731 11.0605193,12.5492786 C12.2577498,13.3790246 12.642609,14.1489142 12.642609,15.433926 C12.6425155,17.0377291 11.0590243,18.6317775 8.19164145,18.6317775 L8.19164145,18.6317775 Z M19.8826607,9.77184145 L17.0422806,9.77184145 L17.0422806,12.5520722 L15.6235154,12.5520722 L15.6235154,9.77184145 L12.7817338,9.77184145 L12.7817338,8.3531947 L15.6235154,8.3531947 L15.6235154,5.56879647 L17.0422806,5.56879647 L17.0422806,8.3531947 L19.8826607,8.3531947 L19.8826607,9.77184145 L19.8826607,9.77184145 Z"></path><path d="M10.3872727,7.6640448 C10.185593,6.16323863 9.07642506,4.95759268 7.91044854,4.92278713 C6.74447202,4.88935549 5.96195312,6.03793865 6.16363276,7.54149263 C6.36531241,9.0436727 7.4744804,10.2897114 8.64185845,10.3230973 C9.80638673,10.3579486 10.5903539,9.16764458 10.3872727,7.6640448 L10.3872727,7.6640448 Z"></path><path d="M9.61325639,13.4194173 C9.2695554,13.3108332 8.89039579,13.2453896 8.48563497,13.2412221 C6.74732179,13.2231324 5.19078658,14.2798014 5.19078658,15.5508909 C5.19078658,16.8484052 6.4462272,17.9259576 8.18454039,17.9259576 C10.6286623,17.9259576 11.4793888,16.9124291 11.4793888,15.6177084 C11.4793888,15.4617704 11.4580856,15.308626 11.4239818,15.1596949 C11.2337012,14.424565 10.5562501,14.0612134 9.61325639,13.4194173 L9.61325639,13.4194173 Z"></path></g></g></g></g></g></g></g></svg>',
			'twitter'   => '<svg width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-1025.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g transform="translate(100.248555, 0.000000)"><g><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M17.0138763,8.63718051 L17.0223789,8.99219713 C17.0223789,12.61747 14.2090016,16.7940902 9.06362446,16.7940902 C7.48438452,16.7940902 6.01446364,16.3402442 4.77607492,15.5619737 C4.99480647,15.5870246 5.2177426,15.6009468 5.44357522,15.6009468 C6.75442286,15.6009468 7.96015601,15.1623969 8.91735182,14.4273128 C7.69316523,14.4050556 6.66066074,13.611489 6.30420586,12.522808 C6.476033,12.5534461 6.64930838,12.5701619 6.83108635,12.5701619 C7.08672476,12.5701619 7.33381387,12.53815 7.56814908,12.4755 C6.28855548,12.2221064 5.32425861,11.1153357 5.32425861,9.78718337 L5.32425861,9.75237782 C5.70201669,9.95841752 6.13233201,10.0809239 6.5910516,10.0962658 C5.84118826,9.60482061 5.34696334,8.76531989 5.34696334,7.81444142 C5.34696334,7.31186759 5.48473338,6.84130571 5.72472142,6.43618742 C7.10372995,8.09567942 9.16584245,9.187154 11.4906944,9.30132537 C11.4423885,9.10082708 11.4182822,8.89061987 11.4182822,8.67624516 C11.4182822,7.16293647 12.6708731,5.93498749 14.2160559,5.93498749 C15.019878,5.93498749 15.7470366,6.26770108 16.2582668,6.80091295 C16.894513,6.67698687 17.4938524,6.44868994 18.034935,6.13543999 C17.8261543,6.77586211 17.3830851,7.31324149 16.8050489,7.65291618 C17.368883,7.58747259 17.9099656,7.43849568 18.4112916,7.22132736 C18.0363833,7.76983536 17.5606118,8.25294555 17.0138763,8.63718051 L17.0138763,8.63718051 Z"></path></g></g></g></g></g></g></svg>'
		);

	$output .= '<div class="dt-blog-items">';
	while( have_posts() ) {
		the_post();
		$img = wp_get_attachment_image_src(get_post_thumbnail_id(), 'db_single_listing');
		$blog_category = get_the_terms(get_the_ID(), 'category');
		$posttags = get_the_tags();
		$tags = array();
		if ( $posttags !== false ) {
			foreach ($posttags as $tag_value) {
				$tags[] = '<a href="'.get_tag_link($tag_value->term_id).'">'.$tag_value->name.'</a>';
			}
		}

		$output .= '<div class="dt-blog-item"><div class="dt-blog-item-inner">';

			$output .= '<div class="dt-blog-item-top">';
				if ( $posttags !== false ) {
					$output .= '<div class="dt-blog-item-tag">'.implode(', ', $tags).'</div>';
				}
				$output .= '<div class="dt-blog-item-share"><img src="'.DIRECTORY_PUBLIC.'images/share.svg" alt="">';
					$output .= '<div class="dt-share-item-wrapper">';
						foreach ($icons as $icon_key => $icon_value) {
							if ( $icon_key == 'twitter' ) {
								$button_url = 'https://twitter.com/intent/tweet?text='.urlencode(get_the_title()).'&url='.urlencode(get_permalink());
							} else if ( $icon_key == 'gplus' ) {
								$button_url = 'https://plus.google.com/share?url='.urlencode(get_permalink());
							} else if ( $icon_key == 'facebook' ) {
								$button_url = 'https://www.facebook.com/dialog/share?app_id=145634995501895&display=popup&href='.urlencode(get_permalink());
							}
							$output .= '<div class="dt-share-item '.$icon_key.'"><a href="'.$button_url.'" target="_blank">'.$icon_value.'</a></div>';
						}
					$output .= '</div>';
				$output .= '</div>';
				$output .= '<div class="clearfix"></div>';
			$output .= '</div>';
			$output .= '<a href="'.get_permalink().'"><div class="dt-blog-item-image" '.(isset($img['0'])?'style="background: url('.$img['0'].')"':'').'></div></a>';
			$output .= '<div class="dt-blog-item-bottom">';
				$output .= '<div class="dt-blog-item-date">'.get_the_date($date_format).'</div>';
				$output .= '<a href="'.get_permalink().'" class="dt-blog-item-title">'.get_the_title().'</a>';
				$output .= '<div class="dt-blog-item-meta">';
					$output .= '<span class="dt-blog-item-author">'.__('by', 'functionality-for-directory-theme').' <a href="'.get_author_posts_url(get_the_author_meta('ID') ).'">'.get_the_author_meta('display_name').'</a></span>';
					if ( isset($blog_category['0']) ) {
						$output .= '<a href="'.get_category_link($blog_category['0']->term_id).'" class="dt-blog-item-category">'.$blog_category['0']->name.'</a>';
					}
					$output .= '<div class="clearfix"></div>';
				$output .= '</div>';
			$output .= '</div>';

		$output .= '</div></div>';
	}
	$output .= '</div>';

	wp_reset_query();
	wp_reset_postdata();

	return $output;
}
add_shortcode('directory_blog','directory_blog_func');

function directory_the_related_posts() {
	global $post;
	$tags = wp_get_post_tags($post->ID);
	  
	if ($tags) {
		$tag_ids = array();

		foreach($tags as $individual_tag) {
			$tag_ids[] = $individual_tag->term_id;
		}

		?>
		<div class="related-article-wrapper">
			<h2 class="related-articles-title"><?php _e( 'You might also like', 'functionality-for-directory-theme' ); ?></h2>
			<div class="related-articles">
				<?php
					echo do_shortcode('[directory_blog limit="3" exclude="'.$post->ID.'" tags="'.implode(',', $tag_ids).'"]');
				?>
				<div class="clearfix"></div>
			</div>
		</div>
	<?php
	}
}

function dt_like_listing() {
	$post_id = ( isset($_POST['post_id']) ? $_POST['post_id'] : '' );
	$db_type = ( isset($_POST['db_type']) ? $_POST['db_type'] : '' );

	if ( is_user_logged_in() ) {
		$user_id = get_current_user_id();
	} else {
		echo json_encode( array( 'save_response' => 'failed', 'reason' => 'not-logged-in' ) );
		die(0);
		return;
	}

	$listing_ratings = get_post_meta( $post_id, 'directory_post_likes', true);
	if ( $db_type == 'like' ) {
		if ( $listing_ratings == '' ) {
			$rating = update_post_meta( $post_id, 'directory_post_likes', array( $user_id => 'liked' ) );
		} else {
			$listing_ratings[$user_id] = 'liked';
			$rating = update_post_meta( $post_id, 'directory_post_likes', $listing_ratings );
		}
	} else if ( $db_type == 'dislike' ) {
		unset($listing_ratings[$user_id]);
		$rating = update_post_meta( $post_id, 'directory_post_likes', $listing_ratings );
	}
	
	if ( $rating ) {
		echo json_encode( array( 'save_response' => 'success', 'type' => $db_type ) );
	} else {
		echo json_encode( array( 'save_response' => 'failed' ) );
	}

	die(0);
}
add_action( 'wp_ajax_dt_like_listing', 'dt_like_listing' );
add_action( 'wp_ajax_nopriv_dt_like_listing', 'dt_like_listing' );

function dt_post_image_module( $value, $data ) {
	/**
	 * @var null|Wp_Post $post ;
	 */
	extract( array_merge( array(
		'post' => null,
	), $data ) );

	$img = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'db_blog_image' );

	$output = '<a href="'.esc_url(get_permalink($post->ID)).'" class="dt-post-thumbnail"'.(isset($img['0'])?' style="background: url('.preg_replace('#^https?://#', '//', $img['0']).')"':'').'></a>';

	return $output;
}
add_filter( 'vc_gitem_template_attribute_dt_post_image_module', 'dt_post_image_module', 10, 2 );

function dt_single_post_image( $atts ) {
	$output = '{{dt_post_image_module}}';
	return $output;
}
add_shortcode( 'dt_single_post_image', 'dt_single_post_image' );

function dt_post_meta_module( $value, $data ) {
	/**
	 * @var null|Wp_Post $post ;
	 */
	extract( array_merge( array(
		'post' => null,
	), $data ) );

	$output = '';
	$date_format = get_option('date_format');
	// .' '.get_option('time_format');

	$output .= '<div class="dt-single-post-meta">';
		$output .= '<span class="dt-single-post-date">'.get_the_date($date_format, $post->ID).' '.__('by', 'functionality-for-directory-theme').'</span>';
		$output .= '<a href="'.get_author_posts_url($post->post_author).'" class="dt-single-post-author"> '.get_the_author_meta('display_name', $post->post_author).'</a>';
	$output .= '</div>';

	return $output;
}
add_filter( 'vc_gitem_template_attribute_dt_post_meta_module', 'dt_post_meta_module', 10, 2 );

function dt_single_post_meta( $atts ) {
	$output = '{{dt_post_meta_module}}';
	return $output;
}
add_shortcode( 'dt_single_post_meta', 'dt_single_post_meta' );

function dt_post_readme_module( $value, $data ) {
	/**
	 * @var null|Wp_Post $post ;
	 */
	extract( array_merge( array(
		'post' => null,
	), $data ) );

	$output = '<a href="'.get_permalink($post->ID).'" class="dt-post-read-more"><span class="dt-readme-item"></span><span class="dt-readme-item"></span><span class="dt-readme-item"></span></a>';

	return $output;
}
add_filter( 'vc_gitem_template_attribute_dt_post_readme_module', 'dt_post_readme_module', 10, 2 );

function dt_single_post_readme( $atts ) {
	$output = '{{dt_post_readme_module}}';
	return $output;
}
add_shortcode( 'dt_single_post_readme', 'dt_single_post_readme' );

function dt_add_vc_grid_shortcodes( $shortcodes ) {
	$shortcodes['dt_single_post_image'] = array(
		"name" => __("WhiteLab - Single post image", "functionality-for-directory-theme"),
		"base" => "dt_single_post_image",
		"class" => "",
		"icon" => "icon-wpb-ui-gap-content",
		"category" => __( "by WhiteLab", "functionality-for-directory-theme" ),
		"params" => array(),
		"post_type" => Vc_Grid_Item_Editor::postType(),
		"show_settings_on_create" => false
	);

	$shortcodes['dt_single_post_meta'] = array(
		"name" => __("WhiteLab - Single post meta", "functionality-for-directory-theme"),
		"base" => "dt_single_post_meta",
		"class" => "",
		"icon" => "icon-wpb-ui-gap-content",
		"category" => __( "by WhiteLab", "functionality-for-directory-theme" ),
		"params" => array(),
		"post_type" => Vc_Grid_Item_Editor::postType(),
		"show_settings_on_create" => false
	);

	$shortcodes['dt_single_post_readme'] = array(
		"name" => __("WhiteLab - Single post read me", "functionality-for-directory-theme"),
		"base" => "dt_single_post_readme",
		"class" => "",
		"icon" => "icon-wpb-ui-gap-content",
		"category" => __( "by WhiteLab", "functionality-for-directory-theme" ),
		"params" => array(),
		"post_type" => Vc_Grid_Item_Editor::postType(),
		"show_settings_on_create" => false
	);

	return $shortcodes;
}
add_filter( 'vc_grid_item_shortcodes', 'dt_add_vc_grid_shortcodes', 100 );

function dt_custom_excerpt_length( $length ) {
	return 45;
}
add_filter( 'excerpt_length', 'dt_custom_excerpt_length', 9999 );

function dt_new_excerpt_more( $more ) {
	return PHP_EOL.'...';
}
add_filter('excerpt_more', 'dt_new_excerpt_more');

function directory_gallery_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'media' => '',
		'autoplay' => '3000',
		'type' => 'tiled'
	), $atts ) );
	$output = '';

	if ( $media == '' ) {
		$media = get_post_meta( get_the_ID(), 'listing_gallery_img', true );
		if ( $media != '' ) {
			$media = str_replace('|', ',', $media);
		} else {
			return;
		}
	}

	$media_arr = explode(',', $media);
	if ( !empty($media_arr) ) {
		$loop = 0;

		wp_enqueue_script( 'jquery.swipe' );

		if ( $type == 'slider' ) {
			$output .= '<div class="db-gallery-container">';
				$output .= '<div class="db-gallery-wrapper" data-autoplay="'.$autoplay.'">';
					$output .= '<div class="db-gallery-inner">';
					$media_count = count($media_arr);
					foreach ($media_arr as $media_id) {
						$extra_class = '';
						if ( $loop == 0 ) {
							$extra_class = 'active';
						}

						$media_url = wp_get_attachment_url( $media_id );

						$output .= '<div class="db-gallery-item '.$extra_class.'"><div class="db-gallery-item-image" style="background: url('.$media_url.') no-repeat"></div></div>';
						$loop++;
					}
					$output .= '</div>';
				$output .= '</div>';
				$output .= '<div class="db-gallery-pagination">';
					for ($i=1; $i <= $media_count; $i++) { 
						$output .= '<div class="db-gallery-pagination-item"><span class="db-gallery-pagination-timer"></div>';
					}
				$output .= '</div>';
				$output .= '<div class="db-gallery-arrows">
								<span class="db-gallery-arrow prev">
									<svg width="7px" height="11px" viewBox="0 0 7 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
										<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
											<g id="Article" transform="translate(-251.000000, -785.000000)" stroke="#CCCCCC" stroke-width="2">
												<g transform="translate(-1.000000, 267.000000)" id="arrows">
													<g transform="translate(253.000000, 519.000000)">
														<g id="arrow-left" transform="translate(2.500000, 4.500000) rotate(-270.000000) translate(-2.500000, -4.500000) translate(-2.000000, 2.000000)">
															<path d="M0.5,0.5 C0.5,0.5 1.13381189,1.13381189 1.91025037,1.91025037 L4.5,4.5" id="Line" fill="#D8D8D8"></path>
															<path d="M8.5,0.5 C8.5,0.5 7.86618811,1.13381189 7.08974963,1.91025037 L4.5,4.5" id="Line-Copy-2"></path>
														</g>
													</g>
												</g>
											</g>
										</g>
									</svg>
								</span>
								<span class="db-gallery-arrow next">
									<svg width="7px" height="11px" viewBox="0 0 7 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
										<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
											<g id="Article" transform="translate(-288.000000, -785.000000)" stroke="#CCCCCC" stroke-width="2">
												<g transform="translate(-1.000000, 267.000000)" id="arrows">
													<g transform="translate(253.000000, 519.000000)">
														<g id="arrow" transform="translate(39.500000, 4.500000) rotate(-90.000000) translate(-39.500000, -4.500000) translate(35.000000, 2.000000)">
															<path d="M0.5,0.5 C0.5,0.5 1.13381189,1.13381189 1.91025037,1.91025037 L4.5,4.5" id="Line" fill="#D8D8D8"></path>
															<path d="M8.5,0.5 C8.5,0.5 7.86618811,1.13381189 7.08974963,1.91025037 L4.5,4.5" id="Line-Copy-2"></path>
														</g>
													</g>
												</g>
											</g>
										</g>
									</svg>
								</span>
							</div>';
			$output .= '</div>';
		} else {
			wp_enqueue_style( 'prettyphoto' );
			wp_enqueue_script( 'prettyphoto' );

			$media_arr = explode(',', $media);
			if ( !empty($media_arr) ) {
				$loop = 0;

				$output .= '<div class="db-gallery-mos-container clearfix">';
					$media_count = count($media_arr);
					$random = rand();
					foreach ($media_arr as $media_id) {
						$last_html = '';
						if ( $loop == 4 && $loop+1 < $media_count) {
							$last_html .= '
							<div class="db-gallery-mos-item-overlay">
								<span>'.sprintf( __('See All<br />%d Images', 'functionality-for-directory-theme'), $media_count ).'</span>
							</div>';
						}

						$image_src = wp_get_attachment_image_src( $media_id, 'full' );
						$image_src = $image_src['0'];
						$image_thumb_src = wp_get_attachment_image_src( $media_id, 'db_single_listing' );
						$image_thumb_src = $image_thumb_src['0'];

						$output .= '<a href="'.$image_src.'" class="db-gallery-mos-item prettyphoto'.($loop > 4?' hidden':'').'" rel="prettyPhoto[whitelab_map]" style="background: url('.$image_thumb_src.')">'.$last_html.'</a>';

						$loop++;
					}
				$output .= '</div>';
			}
		}
	}

	return $output;
}
add_shortcode('directory_gallery','directory_gallery_func');

function directory_package_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
		'image' => '',
		'price' => '',
		'description' => '',
		'explanation' => '',
		'button_text' => 'Choose',
		'button_url' => '#',
		'popular' => ''
	), $atts ) );
	$output = '';

	$output .= '
	<li class="db-package-module-item '.($popular=='true'?'popular':'').'" style="">
		<div class="db-package-inner">';
			if ( $title ) {
				$output .= '<label>'.$title.'</label>';
			}
			$output .= '
			<div class="db-fee-description">';
				if ( $image ) {
					$img = wp_get_attachment_image_src($image);
					$output .= '<img src="'.$img['0'].'" class="db-fee-image" alt="">';
				}
				if ( $price ) {
					$output .= '<span class="db-fee-value">'.$price.'</span>';
				}
				if ( $description ) {
					$output .= '<span class="db-fee-description">'.$description.'</span>';
				}
				if ( $explanation ) {
					$explanation = str_replace('<p>', '', $explanation);
					$explanation = str_replace('</p>', '<br />', $explanation);
					$output .= '<span class="db-fee-pay">'.$explanation.'</span>';
				}
				$output .= '
				<a href="'.$button_url.'" class="db-choose-package" data-id="2">'.$button_text.'</a>
			</div>
		</div>   
	</li>';

	return $output;
}
add_shortcode('directory_package','directory_package_func');

function db_create_listing_func() {
	global $wpdb, $db_user_login;
	$main_settings = get_option( 'db_main_settings', array() );
	$field_data = ( isset($_POST['field_data']) ? json_decode(htmlspecialchars_decode(stripslashes($_POST['field_data'])), true) : '' );

	if ( isset( $field_data['g-recaptcha-response'] ) ) {
		$gcaptcha_options = get_option( 'gglcptch_options', array() );

		$gcaptcha_response = wp_remote_get( add_query_arg( array( 'secret' => $gcaptcha_options['private_key'], 'response' => $field_data['g-recaptcha-response'], 'remoteip' => filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP ) ), 'https://www.google.com/recaptcha/api/siteverify' ) );
		$gcaptcha_body = json_decode( $gcaptcha_response['body'], true );

		if ( !$gcaptcha_body['success'] ) {
			echo json_encode( array( 'response' => 'failed', 'error' => 'form', 'message' => esc_html__('You failed the captcha test!', 'functionality-for-directory-theme') ) );
			die(0);
		}
	}

	if ( is_user_logged_in() ) {
		$listing_author = get_current_user_id();
	} else {
		if ( isset($field_data['login_user_email']) && isset($field_data['login_user_password']) ) {
			$creds = array(
				'user_login'    => $field_data['login_user_email'],
				'user_password' => $field_data['login_user_password'],
				'remember'      => true
			);

			$logged_user = wp_signon( $creds, false );

			if ( is_wp_error( $logged_user ) ) {
				echo '{"save_response": "failed", "message": "'.strip_tags($logged_user->get_error_message()).'"}';
				die(0);
			} else {
				$listing_author = $logged_user->data->ID;
			}
		} else if ( isset($field_data['db_registerusername']) ) {
			if ( $field_data['db_registerpassword'] == $field_data['db_registerpasswordconfirm'] ) {
				$db_user_register = wp_create_user( esc_attr($field_data['db_registerusername']), esc_attr($field_data['db_registerpassword']), esc_attr($field_data['db_registeremail']) );
				if ( is_wp_error( $db_user_register ) ) {
					echo '{"save_response": "failed", "message": "'.strip_tags($db_user_register->get_error_message()).'"}';
					die(0);
				} else {
					$listing_author = $db_user_register;
					wp_update_user( array( 'ID' => $db_user_register, 'role' => 'db_listing_author' ) );

					$replicated_fields = $field_data;
					unset($replicated_fields['db_registerusername']);
					unset($replicated_fields['db_registeremail']);
					unset($replicated_fields['db_registerpassword']);
					unset($replicated_fields['db_registerpasswordconfirm']);
					if ( !empty($replicated_fields) ) {
						foreach ( $replicated_fields as $field_key => $field_value ) {
							if ( strpos( $field_key, 'db_' ) === 0 ) {
								update_user_meta( $db_user_register, $field_key, $field_value );
							}
						}
					}

					$user_validation_code = wp_generate_password( 12, false );
					update_user_meta( $db_user_register, 'db_validation', $user_validation_code );

					if ( function_exists( 'db_send_notification_email' ) ) {
						db_send_notification_email( $db_user_register, 'new_user_confirm', array( 'username' => $field_data['db_registerusername'], 'url_confirm' => add_query_arg( array( 'user' => $db_user_register, 'validation' => $user_validation_code ), get_permalink( $main_settings['account_page_id'] ) ), 'source' => __('the add listing page','directory-builder') ) );
					}
				}
			} else {
				echo '{"save_response": "failed", "message": "'.esc_html__('The passwords provided did not match each other!', 'functionality-for-directory-theme').'"}';
				die(0);
			}
		}
	}

	if ( !isset($listing_author) ) {
		echo '{"save_response": "failed", "message": "'.esc_html__('Unknown author', 'functionality-for-directory-theme').'"}';
		die(0);
	}
	
	$listing_values = array(
		'post_author' => $listing_author,
		'post_content' => $field_data['listing_content'],
		'post_title' => $field_data['listing_title'],
		'post_excerpt' => $field_data['listing_excerpt'],
		'post_status' => $main_settings['new_post_status'],
		'post_type' => 'listings',
		'comment_status' => 'open',
		'post_parent' => 0,
		'menu_order' => 0,
	);
	
	$new_listing_id = wp_insert_post($listing_values);

	if ( $new_listing_id ) {
		if ( function_exists('db_send_notification_email') ) {
			$current_user = get_userdata( $listing_author );
			db_send_notification_email( $listing_author, 'new_listing', array( 'username' => $current_user->data->user_login, 'url_dashboard' => get_permalink( $main_settings['account_page_id'] ), 'url_listing' => get_permalink($new_listing_id) ) );
		}

		$all_listing_values = $field_data;
		unset($all_listing_values['listing_title']);
		unset($all_listing_values['listing_content']);
		unset($all_listing_values['listing_excerpt']);
		unset($all_listing_values['listing_category']);
		if ( isset($all_listing_values['listing_featured_img']) ) {
			add_post_meta( $new_listing_id, '_thumbnail_id', $all_listing_values['listing_featured_img'] );
		}
		unset($all_listing_values['listing_featured_img']); 

		// Add all custom data to the post
		foreach ($all_listing_values as $listing_value_key => $listing_key_value) {
			add_post_meta( $new_listing_id, str_replace('[]', '', $listing_value_key), $listing_key_value, true );
		}

		// Add category to the listing
		wp_set_object_terms( $new_listing_id, intval($field_data['listing_category']), 'listing_category' );

		$package_data = $wpdb->get_results('SELECT * FROM '.$wpdb->prefix.'directory_packages WHERE ID="'.intval($field_data['db-active-package']).'"');
		if ( !empty($package_data) ) {
			$package_data = json_decode($package_data['0']->package_settings, true);
			if ( isset($package_data['listing_sticky']) && $package_data['listing_sticky'] === true ) {
				$sticky_listings = get_option('db_sticky_listings');
				if ( !isset($sticky_listings) || $sticky_listings == '' ) {
					$sticky_listings = array();
				}
				$sticky_listings[] = $new_listing_id;
				update_option('db_sticky_listings', $sticky_listings);
			}

			if ( $package_data['listing_run_type'] == 'forever' ) {
				$run_listing = __('Forever','functionality-for-directory-theme');
			} else {
				$run_listing = $package_data['listing_run_days'].' '.__('days','functionality-for-directory-theme');
			}

			// Add order info
			$order_data = array(
				'listing_package' => $field_data['db-active-package'],
				'listing_package_name' => $package_data['fee_label'],
				'paid_amount' => $main_settings['default_currency_symbol'].$package_data['fee_amount'],
				'payment_history' => array(),
				'payment_status' => 'Processing',
				'category' => $field_data['listing_category'],
				'listing_run_type' => $package_data['listing_run_type'],
				'listing_run_days' => $package_data['listing_run_days'],
				'listing_sticky' => $package_data['listing_sticky'],
				'listing_expires' => 'Unknown'
			);
			add_post_meta( $new_listing_id, 'db_order_info', $order_data, true );

			$return_data = array(
				'save_response' => $new_listing_id,
				'run_listing' => $run_listing,
				'package_id' => $field_data['db-active-package'],
				'amount' => $package_data['fee_amount'],
				'payment_type' => (isset($package_data['payment_type'])?$package_data['payment_type']:'onetime'),
				'payment_cycle' => (isset($package_data['payment_cycle'])?$package_data['payment_cycle']:''),
				'payment_interval' => (isset($package_data['payment_interval'])?$package_data['payment_interval']:''),
				'payment_trial' => (isset($package_data['trial_period'])?$package_data['trial_period']:'false'),
				'trial_cycle' => (isset($package_data['trial_cycle'])?$package_data['trial_cycle']:''),
				'trial_interval' => (isset($package_data['trial_interval'])?$package_data['trial_interval']:''),
				'author' => $listing_author
			);

			if ( $package_data['fee_amount'] == '0' ) {
				$return_data['redirect'] = 'true';
			}

			echo json_encode( $return_data );
		} else {
			echo '{"save_response": "failed", "message": "'.__('We couldn\'t find this package!', 'functionality-for-directory-theme').'"}';
		}
	} else {
		echo '{"save_response": "failed", "message": "'.__('There was an issue while adding your listing!', 'functionality-for-directory-theme').'"}';
	}

	die(0);
}
add_action( 'wp_ajax_db_create_listing', 'db_create_listing_func' );
add_action( 'wp_ajax_nopriv_db_create_listing', 'db_create_listing_func' );

function db_change_active_package_func() {
	global $wpdb;
	$main_settings = get_option( 'db_main_settings');
	$listing_id = ( isset($_POST['listing_id']) ? intval($_POST['listing_id']) : '' );
	$package_id = ( isset($_POST['package_id']) ? intval($_POST['package_id']) : '' );

	$package_data = $wpdb->get_results('SELECT * FROM '.$wpdb->prefix.'directory_packages WHERE ID="'.$package_id.'"');
	if ( !empty($package_data) ) {
		$current_order_data = get_post_meta( $listing_id, 'db_order_info', true );
		$package_data = json_decode( $package_data['0']->package_settings, true );

		$current_order_data['listing_package'] = $package_id;
		$current_order_data['listing_package_name'] = $package_data['fee_label'];
		$current_order_data['paid_amount'] = $package_data['fee_amount'];
		$current_order_data['listing_run_type'] = $package_data['listing_run_type'];
		$current_order_data['listing_run_days'] = $package_data['listing_run_days'];
		$current_order_data['listing_sticky'] = $package_data['listing_sticky'];

		update_post_meta( $listing_id, 'db_order_info', $current_order_data );

		echo '{"save_response": "'.$listing_id.'", "amount": "'.$package_data['fee_amount'].'"'.($package_data['fee_amount']=='0'?', "redirect": "true"':'').'}';
	} else {
		echo '{"save_response": "failed", "message": "'.__('We couldn\'t find this package!', 'functionality-for-directory-theme').'"}';
	}

	die(0);
}
add_action( 'wp_ajax_db_change_active_package', 'db_change_active_package_func' );
add_action( 'wp_ajax_nopriv_db_change_active_package', 'db_change_active_package_func' );

function db_renew_listing_func() {
	global $wpdb, $db_user_login;
	$main_settings = get_option( 'db_main_settings');
	$package_id = ( isset($_POST['package_id']) ? intval($_POST['package_id']) : '0' );

	$package_data = $wpdb->get_results('SELECT * FROM '.$wpdb->prefix.'directory_packages WHERE ID="'.$package_id.'"');
	if ( !empty($package_data) ) {
		$package_data = json_decode($package_data['0']->package_settings, true);

		echo '{"save_response": "0", "name": "'.$package_data['fee_label'].'", "amount": "'.$package_data['fee_amount'].'"}';
	} else {
		echo '{"save_response": "failed", "message": "'.__('We couldn\'t find this package!', 'functionality-for-directory-theme').'"}';
	}

	die(0);
}
add_action( 'wp_ajax_db_renew_listing', 'db_renew_listing_func' );
add_action( 'wp_ajax_nopriv_db_renew_listing', 'db_renew_listing_func' );

function db_save_claim_func() {
	$listing_id = ( isset($_POST['listing_id']) ? $_POST['listing_id'] : '' );
	$package_id = ( isset($_POST['package_id']) ? $_POST['package_id'] : '' );
	
	$claim_info = get_post_meta( $listing_id, 'db_claim_info', true );

	$categories = wp_get_post_terms($listing_id, 'listing_category');
	$cat_list = array();
	foreach ($categories as $cat_value) {
		$cat_list[] = $cat_value->term_id;
	}

	global $wpdb;
	$package_list = $wpdb->get_results('SELECT * FROM '.$wpdb->prefix.'directory_packages WHERE ID="'.intval($package_id).'"');
	$package_data = json_decode($package_list['0']->package_settings, true);

	if ( $claim_info == '' ) {
		$main_settings = get_option( 'db_main_settings', array());
		if ( $main_settings['claims_processing'] == 'manual' ) {
			$claim_value = get_current_user_id() . ':waiting';
		} else {
			$claim_value = get_current_user_id();
		}

		update_post_meta( $listing_id, 'db_claim_info', $claim_value );
		update_post_meta( $listing_id, 'db_order_info', array(
			'listing_package' => $package_id,
			'listing_package_name' =>  $package_list['0']->package_name,
			'paid_amount' =>  esc_html__('Free', 'functionality-for-directory-theme'),
			'payment_history' => array(),
			'payment_status' => 'Completed',
			'category' => implode(',', $cat_list),
			'listing_run_type' => $package_data['listing_run_type'],
			'listing_run_days' => $package_data['listing_run_days'],
			'listing_sticky' => $package_data['listing_sticky'],
			'listing_expires' => strtotime('+ '.$package_data['listing_run_days'].' day'),
			'completed_on' => time()
		) );

		if ( $main_settings['claims_processing'] == 'auto' ) {
			wp_update_post( array( 'ID' => $listing_id, 'post_author' => get_current_user_id() ) );

			if ( function_exists( 'db_send_notification_email' ) ) {
				$current_user = wp_get_current_user();
				db_send_notification_email( get_current_user_id(), 'new_claim', array( 'username' => $current_user->user_login, 'url_dashboard' => get_permalink( $main_settings['account_page_id'] ), 'listing_title' => get_the_title($listing_id), 'listing' => get_permalink($listing_id) ) );
			}
		}

		echo '{"save_response": "'.$listing_id.'"}';
	} else {
		echo '{"save_response": "failed"}';
	}

	die(0);
}
add_action( 'wp_ajax_db_save_claim', 'db_save_claim_func' );
add_action( 'wp_ajax_nopriv_db_save_claim', 'db_save_claim_func' );

// function db_show_public_preview( $query ) {
// 	if ( $query->is_main_query() && $query->is_singular() && is_user_logged_in() ) {
// 		add_filter( 'posts_results', 'db_set_post_to_publish', 10, 2 );
// 	}

// 	return $query;
// }
// add_filter( 'pre_get_posts', 'db_show_public_preview' );

// function db_set_post_to_publish( $posts ) {
// 	remove_filter( 'posts_results', 'set_post_to_publish', 10 );

// 	if ( empty( $posts ) || get_current_user_id() != $posts[0]->post_author ) {
// 		return;
// 	}

// 	$posts[0]->post_status = 'publish';

// 	return $posts;
// }

function directory_slider_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'background' => '',
		'text' => 'Whitelab',
		'delay' => '1500',
		'text_color' => '#fbe094'
	), $atts ) );
	$output = '';

	if ( $background == '' ) {
		return;
	}

	wp_enqueue_script( 'imagesloaded' );
	wp_enqueue_script( 'whitelab_slider_anime' );
	wp_enqueue_script( 'whitelab_slider_main' );

	$output .= '
	<div class="db-custom-slider">
		<div class="segmenter loading" style="background-image: url('.preg_replace('#^https?://#', '//', $background).')"></div>';
		if ( $text != '' ) {
			$text_arr = str_split($text);
			$output .= '<h2 class="trigger-headline trigger-headline--hidden" style="color: '.$text_color.'">';
			foreach ( $text_arr as $text_letter ) {
				$output .= '<span>'.$text_letter.'</span>';
			}
			$output .= '</h2>';
			$output .= '<style type="text/css">';
			$loops = 1;
			$letter_count = count($text_arr);
			$translate_step = 200/count($text_arr);
			foreach ( $text_arr as $text_letter ) {
				$translate = (-100-$translate_step)+($translate_step*$loops);
				if ( $translate >= 0 ) {
					$translate += $translate_step;
				}
				$output .= '.trigger-headline--hidden span:nth-child('.$loops.') {-webkit-transform: translate3d('.$translate.'px,0,0);transform: translate3d('.$translate.'px,0,0);}';
				$loops++;
			}
			$output .= '</style>';
		}
		$output .= '
		<script>
		jQuery(document).ready(function($) {
			var headline = document.querySelector(".trigger-headline"),
				segmenter = new Segmenter(document.querySelector(".segmenter"), {
					pieces: 4,
					animation: {
						duration: 1500,
						easing: "easeInOutExpo",
						delay: 100,
						translateZ: 100
					},
					parallax: true,
					positions: [
						{top: 0, left: 0, width: 45, height: 45},
						{top: 55, left: 0, width: 45, height: 45},
						{top: 0, left: 55, width: 45, height: 45},
						{top: 55, left: 55, width: 45, height: 45}
					],
					onReady: function() {
						document.querySelector(".segmenter").classList.remove("loading");
						setTimeout(function() {
							segmenter.animate();
							headline.classList.remove("trigger-headline--hidden");
						}, '.$delay.');
					}
				});
		});
		</script>
	</div>';

	return $output;
}
add_shortcode('directory_slider','directory_slider_func');

function directory_team_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'image' => '',
		'name' => '',
		'desc' => '',
		'position' => '',
		's_facebook' => '',
		's_gplus' => '',
		's_linkedin' => '',
		's_twitter' => ''
	), $atts ) );
	$output = '';

	$output .= '
	<div class="db-team-member-wrapper">
		'.wp_get_attachment_image($image, 'full').'
		<div class="db-team-member-inner">
			'.($name?'<span class="db-member-name">'.$name.'</span>':'').
			($desc?'<p class="db-member-desc">'.$desc.'</p>':'').'
			<div class="db-member-meta clearfix">
				'.($position?'<span class="db-member-position">'.$position.'</span>':'').
				'<div class="db-member-social">'.
					($s_twitter?'<a class="db-member-social-icon twitter" href="'.$s_twitter.'"><svg width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-1025.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g transform="translate(100.248555, 0.000000)"><g><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M17.0138763,8.63718051 L17.0223789,8.99219713 C17.0223789,12.61747 14.2090016,16.7940902 9.06362446,16.7940902 C7.48438452,16.7940902 6.01446364,16.3402442 4.77607492,15.5619737 C4.99480647,15.5870246 5.2177426,15.6009468 5.44357522,15.6009468 C6.75442286,15.6009468 7.96015601,15.1623969 8.91735182,14.4273128 C7.69316523,14.4050556 6.66066074,13.611489 6.30420586,12.522808 C6.476033,12.5534461 6.64930838,12.5701619 6.83108635,12.5701619 C7.08672476,12.5701619 7.33381387,12.53815 7.56814908,12.4755 C6.28855548,12.2221064 5.32425861,11.1153357 5.32425861,9.78718337 L5.32425861,9.75237782 C5.70201669,9.95841752 6.13233201,10.0809239 6.5910516,10.0962658 C5.84118826,9.60482061 5.34696334,8.76531989 5.34696334,7.81444142 C5.34696334,7.31186759 5.48473338,6.84130571 5.72472142,6.43618742 C7.10372995,8.09567942 9.16584245,9.187154 11.4906944,9.30132537 C11.4423885,9.10082708 11.4182822,8.89061987 11.4182822,8.67624516 C11.4182822,7.16293647 12.6708731,5.93498749 14.2160559,5.93498749 C15.019878,5.93498749 15.7470366,6.26770108 16.2582668,6.80091295 C16.894513,6.67698687 17.4938524,6.44868994 18.034935,6.13543999 C17.8261543,6.77586211 17.3830851,7.31324149 16.8050489,7.65291618 C17.368883,7.58747259 17.9099656,7.43849568 18.4112916,7.22132736 C18.0363833,7.76983536 17.5606118,8.25294555 17.0138763,8.63718051 L17.0138763,8.63718051 Z"></path></g></g></g></g></g></g></svg></a>':'').
					($s_linkedin?'<a class="db-member-social-icon linkedin" href="'.$s_linkedin.'"><svg width="24px" height="23px" viewBox="0 0 24 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-991.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g id="linkedin-logotype-button" transform="translate(66.832370, 0.696970)"><g><path d="M18.4680944,0 L4.26185076,0 C1.90790311,0 0,1.8702997 0,4.17785271 L0,18.1041014 C0,20.4116983 1.90790311,22.2819542 4.26185076,22.2819542 L18.4680944,22.2819542 C20.8220868,22.2819542 22.7299452,20.4116545 22.7299452,18.1041014 L22.7299452,4.17785271 C22.7299899,1.8702997 20.8220868,0 18.4680944,0 L18.4680944,0 Z M8.52374621,16.5374122 L5.68249747,16.5374122 L5.68249747,6.78905995 L8.52374621,6.78905995 L8.52374621,16.5374122 L8.52374621,16.5374122 Z M7.19119988,6.19161041 C6.45533143,6.19161041 5.8600839,5.60669262 5.8600839,4.88532762 C5.8600839,4.16396261 6.45676178,3.57904483 7.19119988,3.57904483 C7.92706833,3.58044698 8.52374621,4.16532095 8.52374621,4.88532762 C8.52374621,5.60669262 7.92706833,6.19161041 7.19119988,6.19161041 L7.19119988,6.19161041 Z M18.4680944,16.5374122 L15.6268457,16.5374122 L15.6268457,10.5101168 C15.6268457,9.80404406 15.4208758,9.30969673 14.5358044,9.30969673 C13.0683138,9.30969673 12.785597,10.5101168 12.785597,10.5101168 L12.785597,16.5374122 L9.94434823,16.5374122 L9.94434823,6.78905995 L12.785597,6.78905995 L12.785597,7.72070441 C13.1919047,7.41573567 14.206199,6.79041829 15.6268457,6.79041829 C16.5474076,6.79041829 18.4680944,7.33077383 18.4680944,10.5950786 L18.4680944,16.5374122 L18.4680944,16.5374122 Z"></path></g></g></g></g></g></g></svg></a>':'').
					($s_gplus?'<a class="db-member-social-icon gplus" href="'.$s_gplus.'"><svg width="24px" height="23px" viewBox="0 0 24 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-958.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g transform="translate(33.416185, 0.696970)"><g><g><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M8.19164145,18.6317775 C5.67650891,18.6317775 3.5547381,17.6280037 3.5547381,16.0242006 C3.5547381,14.3967206 5.49043292,12.8249294 8.00561218,12.8263033 L8.79098085,12.8193422 C8.44727987,12.49217 8.17463627,12.0898453 8.17463627,11.5928129 C8.17463627,11.2976527 8.27120143,11.0150408 8.40472018,10.7630669 L7.98575723,10.7769891 C5.91939343,10.7769891 4.5361336,9.33608512 4.5361336,7.54987344 C4.5361336,5.8026806 6.44627392,4.29491332 8.4771791,4.29491332 L13.0075664,4.29491332 L11.9907123,5.01328156 L10.5548953,5.01328156 C11.5078398,5.37246568 12.0148653,6.46114666 12.0148653,7.57771788 C12.0148653,8.51467413 11.485135,9.3221629 10.7366732,9.89572173 C10.0052633,10.456778 9.86753999,10.6906622 9.86753999,11.1668113 C9.86753999,11.5733493 10.6515071,12.2638731 11.0605193,12.5492786 C12.2577498,13.3790246 12.642609,14.1489142 12.642609,15.433926 C12.6425155,17.0377291 11.0590243,18.6317775 8.19164145,18.6317775 L8.19164145,18.6317775 Z M19.8826607,9.77184145 L17.0422806,9.77184145 L17.0422806,12.5520722 L15.6235154,12.5520722 L15.6235154,9.77184145 L12.7817338,9.77184145 L12.7817338,8.3531947 L15.6235154,8.3531947 L15.6235154,5.56879647 L17.0422806,5.56879647 L17.0422806,8.3531947 L19.8826607,8.3531947 L19.8826607,9.77184145 L19.8826607,9.77184145 Z"></path><path d="M10.3872727,7.6640448 C10.185593,6.16323863 9.07642506,4.95759268 7.91044854,4.92278713 C6.74447202,4.88935549 5.96195312,6.03793865 6.16363276,7.54149263 C6.36531241,9.0436727 7.4744804,10.2897114 8.64185845,10.3230973 C9.80638673,10.3579486 10.5903539,9.16764458 10.3872727,7.6640448 L10.3872727,7.6640448 Z"></path><path d="M9.61325639,13.4194173 C9.2695554,13.3108332 8.89039579,13.2453896 8.48563497,13.2412221 C6.74732179,13.2231324 5.19078658,14.2798014 5.19078658,15.5508909 C5.19078658,16.8484052 6.4462272,17.9259576 8.18454039,17.9259576 C10.6286623,17.9259576 11.4793888,16.9124291 11.4793888,15.6177084 C11.4793888,15.4617704 11.4580856,15.308626 11.4239818,15.1596949 C11.2337012,14.424565 10.5562501,14.0612134 9.61325639,13.4194173 L9.61325639,13.4194173 Z"></path></g></g></g></g></g></g></g></svg></a>':'').
					($s_facebook?'<a class="db-member-social-icon facebook" href="'.$s_facebook.'"><svg width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-925.000000, -5164.000000)" fill="#909FA5"><g transform="translate(0.000000, 5097.000000)"><g transform="translate(925.000000, 67.000000)"><g><g><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M14.2984657,11.1361732 L12.4365846,11.1375471 L12.4351831,17.8200754 L9.88024717,17.8200754 L9.88024717,11.1375929 L8.17603779,11.1375929 L8.17603779,8.8348852 L9.88024717,8.83351129 L9.8773974,7.47751453 C9.8773974,5.59806061 10.3971768,4.45506465 12.6538679,4.45506465 L14.5342024,4.45506465 L14.5342024,6.75914629 L13.3582751,6.75914629 C12.479191,6.75914629 12.4365846,7.08073126 12.4365846,7.68076062 L12.4337348,8.83351129 L14.5469563,8.83351129 L14.2984657,11.1361732 L14.2984657,11.1361732 Z"></path></g></g></g></g></g></g></svg></a>':'').'
				</div>
			</div>
		</div>
	</div>';

	return $output;
}
add_shortcode('directory_team_member','directory_team_func');

function directory_simple_title_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => '',
	), $atts ) );
	$output = '';

	$output .= '<h1 class="db-simple-title">'.$title.'</h1>';

	return $output;
}
add_shortcode('directory_simple_title','directory_simple_title_func');

function whitelab_get_file_contents( $file ) {
	$file_data = @fopen( $file, 'r' );

	if ( $file_data ) {
		$file_line = '';
		while ( !feof($file_data) ) {
			$file_line .= fgets($file_data).PHP_EOL;
		}
		fclose($file_data);
		return rtrim($file_line, PHP_EOL);
	} else {
		return false;
	}

}

function directory_pre_content_func( $content, $post_id ) {
	if ( has_shortcode( $content, 'directory_popular_cities' ) ) { // Check if popular city shortcode is used
		$shortcode_starting = substr( $content, strpos( $content, '[directory_popular_cities' ) );
		$shortcode_ending = strpos( $shortcode_starting, ']' );
		$actual_shortcode = substr($shortcode_starting, 0, $shortcode_ending+1);
		
		if ( strpos( $actual_shortcode, 'cities=' ) !== false ) { // Check if there's an old value used
			$shortcode_cities = substr( $actual_shortcode, strpos( $actual_shortcode, 'cities=' ) );
			$cities_ending = strpos( $shortcode_cities, '"', 9 );
			$actual_cities = substr($shortcode_cities, 0, $cities_ending+1);
			$city_values = substr( $actual_cities, 8, -1 );
			$parsed_cities = explode( '<br />', trim(preg_replace('/\n/', '', nl2br( $city_values ))) );
			$new_values = array();

			if ( !empty($parsed_cities) ) {
				foreach ($parsed_cities as $city_data) {
					if ( $city_data != '' ) {
						$parsed_data = explode(':', $city_data);

						$new_values[] = array( 'city_name' => $parsed_data['0'], 'city_image' => $parsed_data['1'] );
					}
				}
			}

			$new_shorcode_param = 'city_group="' . urlencode( json_encode( $new_values ) ) . '"';

			$content = str_replace($actual_cities, $new_shorcode_param, $content);
		}
	}
	return $content;
}
add_filter( 'content_edit_pre', 'directory_pre_content_func', 10, 2 );

function directory_builder_categories_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'childs' => '',
		'count' => '',
		'hide_empty' => ''
	), $atts ) );
	$output = '';

	$main_settings = get_option( 'db_main_settings' );
	if ( !isset( $main_settings['search_page_id'] ) || $main_settings['search_page_id'] == '' ) {
		return esc_html__( 'Search page is not set at Directory builder settings!', 'directory-builder' );
	}

	$listing_categories = get_terms( array(
		'taxonomy' => 'listing_category',
		'hide_empty' => ($hide_empty=='true'?true:false)
	));

	$categoryHierarchy = array();
	$search_categories = $listing_categories;
	if ( function_exists('db_sort_terms_hierarchicaly') ) {
		db_sort_terms_hierarchicaly($search_categories, $categoryHierarchy);
	}
	if ( empty($categoryHierarchy) ) {
		$categoryHierarchy = $listing_categories;
	}

	$output .= '<ul class="dt-listing-categories">';
	foreach ($categoryHierarchy as $category_data) {
		$output .= '<li><a href="'.add_query_arg( 'search_category', $category_data->term_id, get_permalink($main_settings['search_page_id']) ) .'">'.esc_html($category_data->name).($count==='true'?' ('.$category_data->count.')':'').'</a>';
		if ( !empty($category_data->children) && $childs === 'true' ) {
			$output .= db_display_cat_child( $category_data, array(), $main_settings, $count );
		}
		$output .= '</li>';
	}
	$output .= '</ul>';

	return $output;
}
add_shortcode('directory_builder_categories','directory_builder_categories_func');

function db_display_cat_child( $cat_data, $active_categories = array(), $main_settings = array(), $count ) {
	$output = '<ul class="dt-category-child">';
	foreach ($cat_data->children as $child_value) {
		$output .= '<li><a href="'.add_query_arg( 'search_category', $child_value->term_id, get_permalink($main_settings['search_page_id']) ) .'">'.$child_value->name.($count==='true'?' ('.$child_value->count.')':'').'</a>';
		if ( !empty( $child_value->children ) ) {
			$output .= db_display_cat_child( $child_value, array(), $main_settings, $count );
		}
		$output .= '</li>';
	}
	$output .= '</ul>';

	return $output;
}

function directory_listing_search_func( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'all_active_fields' => ''
	), $atts ) );
	$output = '';


	$main_settings = get_option( 'db_main_settings' );
	$all_active_fields = vc_param_group_parse_atts( $all_active_fields );
	if ( !empty( $all_active_fields ) && isset( $main_settings['search_page_id'] ) && $main_settings['search_page_id'] != '' ) {
		global $wpdb;

		$field_list = $wpdb->get_results('SELECT * FROM '.$wpdb->prefix.'directory_fields WHERE field_active="yes" ORDER BY field_order DESC');
		$all_fields = array();
		foreach ($field_list as $field_value) {
			$field_settings = json_decode($field_value->field_settings, true);

			$all_fields[$field_settings['field_name']] = $field_settings;
		}

		$output .= '<div class="db-main-wrapper"><form action="'.get_permalink( $main_settings['search_page_id'] ).'" class="db-search-side-two db-search-custom-fields db-search-shortcode">';
		foreach ($all_active_fields as $field_name) {
			$output .= db_get_search_field( $field_name['active_field'], '', $all_fields, true );
		}
		$output .= '<div class="db-field-row db-search-button"><input type="submit" class="dt-button dt-button-invert" value="'.__('Search', 'directory-builder').'"></div></form></div>';
	}

	return $output;
}
add_shortcode('listing_search','directory_listing_search_func');
