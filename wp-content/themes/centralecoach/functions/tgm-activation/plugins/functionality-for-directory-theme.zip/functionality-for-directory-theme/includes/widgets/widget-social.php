<?php
/**
 * Social Widget
 *
 * @package      functionality-for-blogpost-theme
 * @since        1.0.0
 * @license      http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */
class Directory_Social_Widget extends WP_Widget {
	
    /**
     * Constructor
     *
     * @return void
     **/
	function __construct() {
		$widget_ops = array( 'classname' => 'widget_socials', 'description' => 'Social icon widget' );
		parent::__construct( 'social-widget', 'Social Widget', $widget_ops );
	}

	/**
	 * Social Options 
	 *
	 */
	function social_options() {
		return array(
			'facebook'  => 'Facebook',
			'gplus'  => 'Google+',
			'vimeo' => 'Vimeo',
			'linkedin'  => 'LinkedIn',
			'twitter'   => 'Twitter'
		);
	}

    /**
     * Outputs the HTML for this widget.
     *
     * @param array  An array of standard parameters for widgets in this theme 
     * @param array  An array of settings for this widget instance 
     * @return void Echoes it's output
     **/
	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		echo $before_widget;
		
		if( $instance['title'] )
			echo $before_title . esc_attr( $instance['title'] ) . $after_title;

		$icons = array(
			'facebook'  => '<svg width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g  stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-925.000000, -5164.000000)" fill="#909FA5"><g   transform="translate(0.000000, 5097.000000)"><g   transform="translate(925.000000, 67.000000)"><g id="facebook-logotype-button"><g  ><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M14.2984657,11.1361732 L12.4365846,11.1375471 L12.4351831,17.8200754 L9.88024717,17.8200754 L9.88024717,11.1375929 L8.17603779,11.1375929 L8.17603779,8.8348852 L9.88024717,8.83351129 L9.8773974,7.47751453 C9.8773974,5.59806061 10.3971768,4.45506465 12.6538679,4.45506465 L14.5342024,4.45506465 L14.5342024,6.75914629 L13.3582751,6.75914629 C12.479191,6.75914629 12.4365846,7.08073126 12.4365846,7.68076062 L12.4337348,8.83351129 L14.5469563,8.83351129 L14.2984657,11.1361732 L14.2984657,11.1361732 Z"  ></path></g></g></g></g></g></g></svg>',
			'gplus'  => '<svg width="24px" height="23px" viewBox="0 0 24 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g  stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-958.000000, -5164.000000)" fill="#909FA5"><g   transform="translate(0.000000, 5097.000000)"><g   transform="translate(925.000000, 67.000000)"><g id="social-google-plus-square-button" transform="translate(33.416185, 0.696970)"><g  ><g id="Group"><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M8.19164145,18.6317775 C5.67650891,18.6317775 3.5547381,17.6280037 3.5547381,16.0242006 C3.5547381,14.3967206 5.49043292,12.8249294 8.00561218,12.8263033 L8.79098085,12.8193422 C8.44727987,12.49217 8.17463627,12.0898453 8.17463627,11.5928129 C8.17463627,11.2976527 8.27120143,11.0150408 8.40472018,10.7630669 L7.98575723,10.7769891 C5.91939343,10.7769891 4.5361336,9.33608512 4.5361336,7.54987344 C4.5361336,5.8026806 6.44627392,4.29491332 8.4771791,4.29491332 L13.0075664,4.29491332 L11.9907123,5.01328156 L10.5548953,5.01328156 C11.5078398,5.37246568 12.0148653,6.46114666 12.0148653,7.57771788 C12.0148653,8.51467413 11.485135,9.3221629 10.7366732,9.89572173 C10.0052633,10.456778 9.86753999,10.6906622 9.86753999,11.1668113 C9.86753999,11.5733493 10.6515071,12.2638731 11.0605193,12.5492786 C12.2577498,13.3790246 12.642609,14.1489142 12.642609,15.433926 C12.6425155,17.0377291 11.0590243,18.6317775 8.19164145,18.6317775 L8.19164145,18.6317775 Z M19.8826607,9.77184145 L17.0422806,9.77184145 L17.0422806,12.5520722 L15.6235154,12.5520722 L15.6235154,9.77184145 L12.7817338,9.77184145 L12.7817338,8.3531947 L15.6235154,8.3531947 L15.6235154,5.56879647 L17.0422806,5.56879647 L17.0422806,8.3531947 L19.8826607,8.3531947 L19.8826607,9.77184145 L19.8826607,9.77184145 Z"  ></path><path d="M10.3872727,7.6640448 C10.185593,6.16323863 9.07642506,4.95759268 7.91044854,4.92278713 C6.74447202,4.88935549 5.96195312,6.03793865 6.16363276,7.54149263 C6.36531241,9.0436727 7.4744804,10.2897114 8.64185845,10.3230973 C9.80638673,10.3579486 10.5903539,9.16764458 10.3872727,7.6640448 L10.3872727,7.6640448 Z"  ></path><path d="M9.61325639,13.4194173 C9.2695554,13.3108332 8.89039579,13.2453896 8.48563497,13.2412221 C6.74732179,13.2231324 5.19078658,14.2798014 5.19078658,15.5508909 C5.19078658,16.8484052 6.4462272,17.9259576 8.18454039,17.9259576 C10.6286623,17.9259576 11.4793888,16.9124291 11.4793888,15.6177084 C11.4793888,15.4617704 11.4580856,15.308626 11.4239818,15.1596949 C11.2337012,14.424565 10.5562501,14.0612134 9.61325639,13.4194173 L9.61325639,13.4194173 Z"  ></path></g></g></g></g></g></g></g></svg>',
			'vimeo' => '<img src="'.DIRECTORY_PUBLIC.'images/social-vimeo.png" alt="">',
			'linkedin'  => '<svg width="24px" height="23px" viewBox="0 0 24 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g  stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-991.000000, -5164.000000)" fill="#909FA5"><g   transform="translate(0.000000, 5097.000000)"><g   transform="translate(925.000000, 67.000000)"><g id="linkedin-logotype-button" transform="translate(66.832370, 0.696970)"><g  ><path d="M18.4680944,0 L4.26185076,0 C1.90790311,0 0,1.8702997 0,4.17785271 L0,18.1041014 C0,20.4116983 1.90790311,22.2819542 4.26185076,22.2819542 L18.4680944,22.2819542 C20.8220868,22.2819542 22.7299452,20.4116545 22.7299452,18.1041014 L22.7299452,4.17785271 C22.7299899,1.8702997 20.8220868,0 18.4680944,0 L18.4680944,0 Z M8.52374621,16.5374122 L5.68249747,16.5374122 L5.68249747,6.78905995 L8.52374621,6.78905995 L8.52374621,16.5374122 L8.52374621,16.5374122 Z M7.19119988,6.19161041 C6.45533143,6.19161041 5.8600839,5.60669262 5.8600839,4.88532762 C5.8600839,4.16396261 6.45676178,3.57904483 7.19119988,3.57904483 C7.92706833,3.58044698 8.52374621,4.16532095 8.52374621,4.88532762 C8.52374621,5.60669262 7.92706833,6.19161041 7.19119988,6.19161041 L7.19119988,6.19161041 Z M18.4680944,16.5374122 L15.6268457,16.5374122 L15.6268457,10.5101168 C15.6268457,9.80404406 15.4208758,9.30969673 14.5358044,9.30969673 C13.0683138,9.30969673 12.785597,10.5101168 12.785597,10.5101168 L12.785597,16.5374122 L9.94434823,16.5374122 L9.94434823,6.78905995 L12.785597,6.78905995 L12.785597,7.72070441 C13.1919047,7.41573567 14.206199,6.79041829 15.6268457,6.79041829 C16.5474076,6.79041829 18.4680944,7.33077383 18.4680944,10.5950786 L18.4680944,16.5374122 L18.4680944,16.5374122 Z"  ></path></g></g></g></g></g></g></svg>',
			'twitter'   => '<svg width="23px" height="23px" viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g  stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" fill-opacity="0.3"><g transform="translate(-1025.000000, -5164.000000)" fill="#909FA5"><g   transform="translate(0.000000, 5097.000000)"><g   transform="translate(925.000000, 67.000000)"><g id="twitter-logo" transform="translate(100.248555, 0.000000)"><g  ><path d="M18.4624473,0 L4.26054679,0 C1.90729055,0 0,1.86969921 0,4.17657445 L0,18.0985656 C0,20.4054409 1.90729055,22.2751401 4.26054679,22.2751401 L18.4624473,22.2751401 C20.8157036,22.2751401 22.7229941,20.4053951 22.7229941,18.0985656 L22.7229941,4.17657445 C22.7230408,1.86969921 20.8157036,0 18.4624473,0 L18.4624473,0 Z M17.0138763,8.63718051 L17.0223789,8.99219713 C17.0223789,12.61747 14.2090016,16.7940902 9.06362446,16.7940902 C7.48438452,16.7940902 6.01446364,16.3402442 4.77607492,15.5619737 C4.99480647,15.5870246 5.2177426,15.6009468 5.44357522,15.6009468 C6.75442286,15.6009468 7.96015601,15.1623969 8.91735182,14.4273128 C7.69316523,14.4050556 6.66066074,13.611489 6.30420586,12.522808 C6.476033,12.5534461 6.64930838,12.5701619 6.83108635,12.5701619 C7.08672476,12.5701619 7.33381387,12.53815 7.56814908,12.4755 C6.28855548,12.2221064 5.32425861,11.1153357 5.32425861,9.78718337 L5.32425861,9.75237782 C5.70201669,9.95841752 6.13233201,10.0809239 6.5910516,10.0962658 C5.84118826,9.60482061 5.34696334,8.76531989 5.34696334,7.81444142 C5.34696334,7.31186759 5.48473338,6.84130571 5.72472142,6.43618742 C7.10372995,8.09567942 9.16584245,9.187154 11.4906944,9.30132537 C11.4423885,9.10082708 11.4182822,8.89061987 11.4182822,8.67624516 C11.4182822,7.16293647 12.6708731,5.93498749 14.2160559,5.93498749 C15.019878,5.93498749 15.7470366,6.26770108 16.2582668,6.80091295 C16.894513,6.67698687 17.4938524,6.44868994 18.034935,6.13543999 C17.8261543,6.77586211 17.3830851,7.31324149 16.8050489,7.65291618 C17.368883,7.58747259 17.9099656,7.43849568 18.4112916,7.22132736 C18.0363833,7.76983536 17.5606118,8.25294555 17.0138763,8.63718051 L17.0138763,8.63718051 Z"  ></path></g></g></g></g></g></g></svg>'
		);
			
		echo '<p class="socials">';
		$socials = $this->social_options();
		foreach( $socials as $key => $label ) {
			if( !empty( $instance[$key] ) ) {
				echo '<a class="social-icon ' . $key . '" href="' . esc_url( $instance[$key] ) . '">'.$icons[$key].'</a> ';
			}
		}
		echo '</p>';

		echo $after_widget;
	}

    /**
     * Deals with the settings when they are saved by the admin. Here is
     * where any validation should be dealt with.
     *
     * @param array  An array of new settings as submitted by the admin
     * @param array  An array of the previous settings 
     * @return array The validated and (if necessary) amended settings
     **/
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		$instance['title'] = esc_attr( $new_instance['title'] );
		$socials = $this->social_options();
		foreach( $socials as $key => $label )
			$instance[$key] = esc_url( $new_instance[$key] );

		return $instance;
	}
	
    /**
     * Displays the form for this widget on the Widgets page of the WP Admin area.
     *
     * @param array  An array of the current settings for this widget
     * @return void Echoes it's output
     **/
	function form( $instance ) {
	
		$socials = $this->social_options();
		$defaults = array( 'title' => '' );
		foreach( $socials as $key => $label )
			$defaults[$key] = '';
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		echo '<p><label for="' . $this->get_field_id( 'title' ) . '">Title: <input class="widefat" id="' . $this->get_field_id( 'title' ) .'" name="' . $this->get_field_name( 'title' ) . '" value="' . esc_attr( $instance['title'] ) . '" /></label></p>';
		
		foreach( $socials as $key => $label )
			echo '<p><label for="' . $this->get_field_id( $key ) . '">' . $label . ' URL: <input class="widefat" id="' . $this->get_field_id( $key ) .'" name="' . $this->get_field_name( $key ) . '" value="' . esc_url( $instance[$key] ) . '" /></label></p>';
		
	}
}

function directory_register_social_widget() {
	register_widget('Directory_Social_Widget');
}
add_action( 'widgets_init', 'directory_register_social_widget' );