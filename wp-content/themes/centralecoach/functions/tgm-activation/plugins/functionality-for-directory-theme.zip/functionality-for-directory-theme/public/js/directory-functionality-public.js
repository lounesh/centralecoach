(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note that this assume you're going to use jQuery, so it prepares
	 * the $ function reference to be used within the scope of this
	 * function.
	 *
	 * From here, you're able to define handlers for when the DOM is
	 * ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * Or when the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and so on.
	 *
	 * Remember that ideally, we should not attach any more than a single DOM-ready or window-load handler
	 * for any particular page. Though other scripts in WordPress core, other plugins, and other themes may
	 * be doing this, we should try to minimize doing that in our own work.
	 */

})( jQuery );

jQuery(document).ready(function($) {
	jQuery(document).on('click', '.dt-listing-likes:not(.liked):not(.not-logged-in), .db-single-listing-like', function() {
		var like_icon = jQuery(this);
		if ( !like_icon.hasClass('in-process') ) {
			like_icon.addClass('in-process');

			var like_type = 'like';
			if ( like_icon.hasClass('liked') ) {
				like_type = 'dislike';
			}

			jQuery.ajax({
				type: 'POST',
				url: dt_main.ajaxurl,
				data: { 
					'action': 'dt_like_listing',
					'post_id': jQuery(this).attr('data-id'),
					'db_type': like_type
				},
				success: function(data) {
					like_icon.removeClass('in-process');

					var parsed_response = jQuery.parseJSON(data);

					if ( parsed_response.save_response == 'success' ) {
						if ( parsed_response.type == 'like' ) {
							like_icon.addClass('liked');
						} else {
							like_icon.removeClass('liked');
						}
					} else if ( parsed_response.save_response == 'failed' && like_icon.find('.db-favorite-tooltip').length ) {
						jQuery('.db-favorite-tooltip').removeClass('shown');
						like_icon.find('.db-favorite-tooltip').addClass('shown');
					}
				}
			});
		}
	});

	jQuery(document).on('click', '.db-favorite-tooltip a', function() {
		jQuery('.dt-login-register-modal').addClass('db-animate-dialog');
	});

	jQuery(document).on('click', '.dt-listing-likes.not-logged-in', function() {
		if ( jQuery(this).find('.db-favorite-tooltip').length ) {
			jQuery('.db-favorite-tooltip').removeClass('shown');
			jQuery(this).find('.db-favorite-tooltip').addClass('shown');
		}
	});

	var $pagination_update, $slide_active_slider;
	function db_update_gallery_pagination( active_item, update_speed, autoplay_speed ) {
		var current_pagination = jQuery('.db-gallery-pagination .db-gallery-pagination-item').eq(active_item);
		var pagination_update_time = 0;
		var $pagination_update = setInterval(function() {
			if ( pagination_update_time == autoplay_speed ) {
				clearInterval($pagination_update);
			}
			
			var pagination_progress = pagination_update_time/autoplay_speed*100;
			current_pagination.find('span').css('width', pagination_progress+'%');

			if ( pagination_update_time == autoplay_speed ) {
				jQuery('.db-gallery-pagination-item span').css('width', '0%');
			}

			pagination_update_time += update_speed;
		}, update_speed);
	}

	function db_update_gallery_slider( autoplay_speed ) {
		$slide_active_slider = setInterval(function() {
			jQuery('.db-gallery-wrapper .db-gallery-item').removeClass('gallery-fade-out');
			var active_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active');
			setTimeout(function() {
				active_slide.addClass('gallery-fade-out');
			}, autoplay_speed);
			if ( active_slide.next().length ) {
				active_slide = active_slide.next();
			} else {
				active_slide = jQuery('.db-gallery-wrapper .db-gallery-item').first();
			}
			var item_width = jQuery('.db-gallery-wrapper').outerWidth();
			var slider_left = item_width*active_slide.index()+(30*active_slide.index());
			jQuery('.db-gallery-wrapper .db-gallery-inner').css('left', '-'+slider_left+'px');

			jQuery('.db-gallery-wrapper .db-gallery-item').removeClass('active');
			active_slide.addClass('active');

			jQuery('.db-gallery-wrapper').removeClass('animation');

			db_update_gallery_pagination( active_slide.index(), update_speed, autoplay_speed );
		}, autoplay_speed+500);
	}

	if ( jQuery('.db-gallery-wrapper').length ) {
		var margin = (jQuery('.entry-content-inner').outerWidth()-jQuery('#entry-content-wrapper').outerWidth())/2+30;
		jQuery('.db-gallery-wrapper').css('margin', '0 -'+margin+'px');

		var autoplay_speed = parseInt(jQuery('.db-gallery-wrapper').attr('data-autoplay'));
		var update_speed = 100;
		var active_item = jQuery('.db-gallery-wrapper .db-gallery-item.active');

		db_update_gallery_pagination( active_item.index(), update_speed, autoplay_speed );

		var item_width = jQuery('.db-gallery-wrapper').outerWidth();
		jQuery('.db-gallery-wrapper .db-gallery-item').each(function() {
			var item_left = item_width*jQuery(this).index()+(30*jQuery(this).index());
			jQuery(this).css('left', item_left);
		});
		var active_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active');
		setTimeout(function() {
			active_slide.addClass('gallery-fade-out');
		}, autoplay_speed);

		db_update_gallery_slider( autoplay_speed );

		jQuery(document).on('click', '.db-gallery-wrapper .db-gallery-item:not(.active)', function(e) {
			jQuery('.db-gallery-wrapper .db-gallery-item').removeClass('active');
			clearInterval($pagination_update);
			clearInterval($slide_active_slider);
			jQuery('.db-gallery-pagination-item span').css('width', '0%');
			jQuery(this).addClass('active');

			var active_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active');
			var item_width = jQuery('.db-gallery-wrapper').outerWidth();
			var slider_left = item_width*active_slide.index()+(30*active_slide.index());
			jQuery('.db-gallery-wrapper .db-gallery-inner').css('left', '-'+slider_left+'px');
			db_update_gallery_pagination( active_slide.index(), update_speed, autoplay_speed );
			db_update_gallery_slider( autoplay_speed );
		});

		jQuery(document).on('click', '.db-gallery-arrow.prev', function() {
			// if ( !jQuery('.db-gallery-wrapper').hasClass('animation') ) {
				if ( jQuery('.db-gallery-wrapper .db-gallery-item.active').prev().length ) {
					jQuery('.db-gallery-wrapper .db-gallery-item.active').prev().click();
				} else {
					jQuery('.db-gallery-wrapper .db-gallery-item').last().click();
				}
				jQuery('.db-gallery-wrapper').addClass('animation');
			// }
		});

		jQuery(document).on('click', '.db-gallery-arrow.next', function() {
			// if ( !jQuery('.db-gallery-wrapper').hasClass('animation') ) {
				if ( jQuery('.db-gallery-wrapper .db-gallery-item.active').next().length ) {
					jQuery('.db-gallery-wrapper .db-gallery-item.active').next().click();
				} else {
					jQuery('.db-gallery-wrapper .db-gallery-item').first().click();
				}
				jQuery('.db-gallery-wrapper').addClass('animation');
			// }
		});

		jQuery( window ).resize(function() {
			var margin = (jQuery('.entry-content-inner').outerWidth()-jQuery('#entry-content-wrapper').outerWidth())/2+30;
			jQuery('.db-gallery-wrapper').css('margin', '0 -'+margin+'px');

			var item_width = jQuery('.db-gallery-wrapper').outerWidth();
			jQuery('.db-gallery-wrapper .db-gallery-item').each(function() {
				var item_left = item_width*jQuery(this).index()+(30*jQuery(this).index());
				jQuery(this).css('left', item_left);
			});

			var active_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active');
			var slider_left = item_width*active_slide.index()+(30*active_slide.index());
			jQuery('.db-gallery-wrapper .db-gallery-inner').css('left', '-'+slider_left+'px');

			clearInterval($pagination_update);
			clearInterval($slide_active_slider);

			db_update_gallery_pagination( active_slide.index(), update_speed, autoplay_speed );
			db_update_gallery_slider( autoplay_speed );
		});

		jQuery('.db-gallery-wrapper').on('swipeleft', function() {
			if ( jQuery('.db-gallery-wrapper .db-gallery-item.active').next().length ) {
				var next_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active').next();
			} else {
				var next_slide = jQuery('.db-gallery-wrapper .db-gallery-item').first();
			}

			jQuery('.db-gallery-wrapper .db-gallery-item').removeClass('active');
			next_slide.addClass('active');

			clearInterval($pagination_update);
			clearInterval($slide_active_slider);
			jQuery('.db-gallery-pagination-item span').css('width', '0%');
			jQuery(this).addClass('active');

			var active_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active');
			var item_width = jQuery('.db-gallery-wrapper').outerWidth();
			var slider_left = item_width*active_slide.index()+(30*active_slide.index());
			jQuery('.db-gallery-wrapper .db-gallery-inner').css('left', '-'+slider_left+'px');
			db_update_gallery_pagination( active_slide.index(), update_speed, autoplay_speed );
			db_update_gallery_slider( autoplay_speed );

			setTimeout(function() {
				next_slide.removeClass('gallery-fade-out');
			}, (autoplay_speed + 50));
		});

		jQuery('.db-gallery-wrapper').on('swiperight', function() {
			if ( jQuery('.db-gallery-wrapper .db-gallery-item.active').prev().length ) {
				var next_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active').prev();
			} else {
				var next_slide = jQuery('.db-gallery-wrapper .db-gallery-item').last();
			}

			jQuery('.db-gallery-wrapper .db-gallery-item').removeClass('active');
			next_slide.addClass('active');

			clearInterval($pagination_update);
			clearInterval($slide_active_slider);
			jQuery('.db-gallery-pagination-item span').css('width', '0%');
			jQuery(this).addClass('active');

			var active_slide = jQuery('.db-gallery-wrapper .db-gallery-item.active');
			var item_width = jQuery('.db-gallery-wrapper').outerWidth();
			var slider_left = item_width*active_slide.index()+(30*active_slide.index());
			jQuery('.db-gallery-wrapper .db-gallery-inner').css('left', '-'+slider_left+'px');
			db_update_gallery_pagination( active_slide.index(), update_speed, autoplay_speed );
			db_update_gallery_slider( autoplay_speed );

			setTimeout(function() {
				next_slide.removeClass('gallery-fade-out');
			}, (autoplay_speed + 50));
		});
	}

	if ( jQuery('.prettyphoto').length ) {
		jQuery('.prettyphoto').prettyPhoto({ social_tools: false });
		jQuery("a[rel^='prettyPhoto']").prettyPhoto({ social_tools: false });
	}

	jQuery(document).on('click', '.db-single-listing-share:not(.active)', function() {
		jQuery(this).addClass('active');
	});

	if ( jQuery('.db-slider-field').length ) {
		var slider_field = jQuery('.db-slider-field');
		var max_value = slider_field.find('input').attr('data-default')*2;
		slider_field.slider({
			min: 0,
			max: max_value,
			value: slider_field.find('input').val(),
			create: function( event, ui ) {
				slider_field.find('.ui-slider-handle').attr('data-value', slider_field.find('input').val()+slider_field.attr('data-value'));
				var slided_percentage = slider_field.find('input').val()/(max_value)*100;
				slider_field.find('.db-slider-left').css('width', slided_percentage+'%');
			},
			slide: function( event, ui ) {
				slider_field.find('.ui-slider-handle').attr('data-value', ui.value+slider_field.attr('data-value'));
				var slided_percentage = ui.value/(max_value)*100;
				slider_field.find('.db-slider-left').css('width', slided_percentage+'%');
				slider_field.find('input').val(ui.value);
			},
			stop: function() {
				jQuery('.db-find-listings').attr('data-page', '1');
				jQuery('.db-find-listings').click();
			}
		});
	}

	jQuery(document).on('submit', 'form.db-search-shortcode', function (e) {
		jQuery(this).find('input[name]').filter(function () { return !this.value; }).prop('name', '');
	});
});

jQuery(window).load(function() {

	if ( jQuery('.dt-listing-likes').length ) {
		like_init();
	}

	jQuery('.pp_hoverContainer').live('swipeleft', function() {
		jQuery('.pp_next').click();
	});

	jQuery('.pp_hoverContainer').live('swiperight', function() {
		jQuery('.pp_previous').click();
	});

});

// taken from mo.js demos
function isIOSSafari() {
	var userAgent;
	userAgent = window.navigator.userAgent;
	return userAgent.match(/iPad/i) || userAgent.match(/iPhone/i);
};

// taken from mo.js demos
function isTouch() {
	var isIETouch;
	isIETouch = navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
	return [].indexOf.call(window, 'ontouchstart') >= 0 || isIETouch;
};

// taken from mo.js demos
var isIOS = isIOSSafari(),
	clickHandler = isIOS || isTouch() ? 'touchstart' : 'click';

function extend( a, b ) {
	for( var key in b ) { 
		if( b.hasOwnProperty( key ) ) {
			a[key] = b[key];
		}
	}
	return a;
}

function Animocon(el, options) {
	this.el = el;
	this.options = extend( {}, this.options );
	extend( this.options, options );

	this.checked = false;

	this.timeline = new mojs.Timeline();
	
	for(var i = 0, len = this.options.tweens.length; i < len; ++i) {
		this.timeline.add(this.options.tweens[i]);
	}

	var self = this;
	this.el.addEventListener(clickHandler, function() {
		if( self.checked ) {
			self.options.onUnCheck();
		} else {
			if ( !jQuery(self.el).hasClass('liked') ) {
				self.options.onCheck();
				self.timeline.replay();
			}	
		}
		self.checked = !self.checked;
	});
}

function like_init() {
	Animocon.prototype.options = {
		tweens : [
			new mojs.Burst({})
		],
		onCheck : function() { return false; },
		onUnCheck : function() { return false; }
	};
		
	jQuery('.dt-listing-likes:not(.not-logged-in)').each(function() {
		var el3 = jQuery(this)['0'], el3span = jQuery(this).find('svg')['0'];

		new Animocon(el3, {
			tweens : [
				// burst animation
				new mojs.Burst({
					parent: 		el3,
					count: 			6,
					radius: 		{40:90},
					children: {
						fill: 			[ '#247BA0', '#DE8AA0', '#8AAEDE', '#8ADEAD', '#DEC58A', '#8AD1DE' ],
						opacity: 		0.6,
						scale: 			1,
						radius:     { 7: 0 },
						duration: 	1500,
						delay: 			300,
						easing: 		mojs.easing.bezier(0.1, 1, 0.3, 1)
					}
				}),
				// ring animation
				new mojs.Shape({
					parent: 			el3,
					type: 				'circle',
					scale:        { 0: 1 },
					radius: 			50,
					fill: 				'transparent',
					stroke: 			'#247BA0',
					strokeWidth: 	{35:0},
					opacity: 			0.6,
					duration:  		750,
					easing: 			mojs.easing.bezier(0, 1, 0.5, 1)
				}),
				// icon scale animation
				new mojs.Tween({
					duration : 1100,
					onUpdate: function(progress) {
						if(progress > 0.3) {
							var elasticOutProgress = mojs.easing.elastic.out(1.43*progress-0.43);
							el3span.style.WebkitTransform = el3span.style.transform = 'scale3d(' + elasticOutProgress + ',' + elasticOutProgress + ',1)';
						}
						else {
							el3span.style.WebkitTransform = el3span.style.transform = 'scale3d(0,0,1)';
						}
					}
				})
			],
			onCheck : function() {
				setTimeout(function() {
					jQuery(el3).addClass('liked');
				}, 250);
			},
			onUnCheck : function() {
				// jQuery(el3).removeClass('liked');
			}
		});
	});
	
}

jQuery( document ).ajaxStop(function() {
	if ( jQuery('.dt-listing-likes').length ) {
		setTimeout(function() {
			like_init();
		}, 500);
	}
});