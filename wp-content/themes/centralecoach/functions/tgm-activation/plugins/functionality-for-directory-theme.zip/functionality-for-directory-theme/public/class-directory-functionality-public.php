<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    directory_func
 * @subpackage directory_func/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    directory_func
 * @subpackage directory_func/public
 * @author     Your Name <email@example.com>
 */
class directory_func_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $directory_func    The ID of this plugin.
	 */
	private $directory_func;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $directory_func       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $directory_func, $version ) {

		$this->directory_func = $directory_func;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in directory_func_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The directory_func_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->directory_func, plugin_dir_url( __FILE__ ) . 'css/directory-functionality-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in directory_func_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The directory_func_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_register_script( 'jquery.mo', plugin_dir_url( __FILE__ ) . 'js/mo.min.js', array( 'jquery' ), $this->version, true );
		wp_register_script( 'whitelab_slider_anime', plugin_dir_url( __FILE__ ) . 'js/anime.min.js', array( 'jquery' ), $this->version, true );
		wp_register_script( 'whitelab_slider_main', plugin_dir_url( __FILE__ ) . 'js/main.js', array( 'jquery' ), $this->version, true );
		wp_register_script( 'jquery.swipe', plugin_dir_url( __FILE__ ) . 'js/jquery.mobile.swipe.min.js', array( 'jquery' ), '', false );

		wp_enqueue_script( $this->directory_func, plugin_dir_url( __FILE__ ) . 'js/directory-functionality-public.js', array( 'jquery' ), $this->version, false );
		wp_localize_script( $this->directory_func, 'dt_main', array( 
			'ajaxurl' => admin_url( 'admin-ajax.php' )
		));
	}

}
