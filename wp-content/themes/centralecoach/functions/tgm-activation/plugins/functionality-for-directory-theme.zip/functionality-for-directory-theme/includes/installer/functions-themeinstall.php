<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $pagenow;

/**
* ----------------------------------------------------------------------
* Theme has been just activated
*/

if ( is_admin() && $pagenow == "themes.php" ) {
	// Update theme option '_basic_config_done'
	// if URL has ?basic_setup=completed variable set
	if ( isset($_GET['basic_setup']) && $_GET['basic_setup'] == 'completed' ) {
		update_option('whitelab_basic_config_done', true);
		define ('LBMN_THEME_CONFUGRATED', true);
	}

	// Update theme option '_basic_config_done'
	// if URL has ?demoimport=completed variable set
	if ( isset($_GET['demoimport']) && $_GET['demoimport'] == 'completed' ) {
		update_option('whitelab_democontent_imported', true);
	}

	if ( strtolower( wp_get_theme()->get( 'Name' ) ) == 'whitelab' && !get_option('whitelab_hide_quicksetup' ) ) {
		add_action( 'admin_footer', 'lbmn_setmessage_themeinstall' );
	}
}

/**
 * ----------------------------------------------------------------------
 * Output Theme Installer HTML
 */

function lbmn_setmessage_themeinstall() {
?>
<img src="<?php echo includes_url() . 'images/spinner.gif' ?>" class="theme-installer-spinner" style="position:fixed; left:50%; top:50%;" />
<style type="text/css">.vhman-message.quick-setup{display:none;}</style>
<div class="updated vhman-message quick-setup">
	<div class="message-container">
	<p class="before-header">WhiteLab Quick Setup</p>
	<h4>Thank you for creating with <a href="<?php echo WHITELAB_DEVELOPER_URL; ?>" target="_blank"><?php echo WHITELAB_DEVELOPER_NAME_DISPLAY; ?></a>!</h4>
	<h5>Just a few steps left to release the full power of our theme.</h5>

	<!-- Step 1 -->
		<?php
			// Check is this step is already done
			if ( !get_option('whitelab_required_plugins_installed') ) {
				echo '<p id="theme-setup-step-1" class="submit step-plugins">';
			} else {
				echo '<p id="theme-setup-step-1" class="submit step-plugins step-completed">';
			}
		?>
		<span class="step"><span class="number">1</span></span>
		<img src="<?php echo includes_url() . '/images/spinner.gif' ?>" class="customspinner" />

		<span class="step-body"><a href="<?php echo add_query_arg( array('page' => 'install-required-plugins'), admin_url('themes.php') ); ?>" class="button button-primary" id="do_plugins-install">Install recommended plugins</a>
		<span class="step-description">
		Install recommended plugins.
		</span></span><br />
		<span class="error" style="display:none">Automatic plugin installation failed. Please try to <a href="/wp-admin/themes.php?page=install-required-plugins">install required plugins manually</a>.</span>
		</p>

	<!-- Step 2 -->
		<?php
			// Check is this step is already done
			if ( !get_option('whitelab_democontent_imported') ) {
				echo '<p id="theme-setup-step-2" class="submit step-demoimport">';
			} else {
				echo '<p id="theme-setup-step-2" class="submit step-demoimport step-completed">';
			}
		?>
		<span class="step"><span class="number">2</span></span>
		<img src="<?php echo includes_url() . '/images/spinner.gif' ?>" class="customspinner" />
		<span class="step-body">
		<a href="#" class="button button-primary" id="do_demo-import">Import all demo content</a>
		<span class="step-description">
		Optional step to recreate theme demo website<br />
		on your server.
		</span></span><br />
		<span class="error" style="display:none">Something went wrong (<a href="#" class="show-error-log">show log</a>).</span>
		</p>

	<!-- Step 3 -->
		<p class="submit step-tour">
		<span class="step"><span class="number">3</span></span> 
		<span class="step-body">
			<a href="<?php echo add_query_arg('theme_tour', 'true', admin_url('themes.php') ); ?>" class="button  button-primary">Take a quick tour</a> 
			<span class="step-description">2 minutes interactive introduction<br /> 
			to our theme basic controls.  </span>
		</span>
		</p>


	<p class="submit action-skip"> <a class="skip button-primary" href="<?php echo add_query_arg('hide_quicksetup', 'true', admin_url('themes.php') ); ?>">Hide this message</a></p></div>
</div>
<style type="text/css">.theme-installer-spinner{display:none;}</style>
<style type="text/css">.vhman-message.quick-setup{display:block;}</style>
<?php
}

/**
* ----------------------------------------------------------------------
* Start basic theme settings setup process
*/
add_action( 'admin_notices', 'pvt_wordpress_content_importer' );
function pvt_wordpress_content_importer() {
	$theme_dir = DIRECTORY_PLUGIN;

	if ( is_admin() && isset($_GET['importcontent']) ) {
		if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);
		
		$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
		if ( ! class_exists( 'WP_Importer' ) ) {
			if ( file_exists( $class_wp_importer ) ) {
				include $class_wp_importer;
			}
		}
		if ( ! class_exists('pvt_WP_Import') ) {
			$class_wp_import = $theme_dir . 'includes/installer/importer/wordpress-importer.php';
			if ( file_exists( $class_wp_import ) ) {
				include $class_wp_import;
			}
		}
		if ( class_exists( 'WP_Importer' ) && class_exists( 'pvt_WP_Import' ) ) {
			$importer = new pvt_WP_Import();
			$files_to_import = array();

			// Live Composer has links to images hard-coded, so before importing
			// media we need to check that the Settings > Media >
			// 'Organize my uploads into month- and year-based folders' unchecked
			// as on demo server. After import is done we set back original state
			// of this setting.

			if ( $_GET['importcontent'] == 'alldemocontent' ) {
				$import_path = $theme_dir . '/includes/installer/';
				$files_to_import[] = $import_path . 'import.xml';
			}
			
			if ( file_exists( $class_wp_importer ) ) {
				// Import included images
				$importer->fetch_attachments = true;

				foreach ($files_to_import as $import_file) {
					if( is_file($import_file) ) {
						ob_start();
							$importer->import( $import_file );

							$log = ob_get_contents();
						ob_end_clean();

						// output log in the hidden div
						echo '<div class="ajax-log">';
						echo $log;
						echo '</div>';


						if ( stristr($log, 'error') || !stristr($log, 'All done.') ) {
							// Set marker div that will be fildered by ajax request
							echo '<div class="ajax-request-error"></div>';

							// output log in the div
							echo '<div class="ajax-error-log">';
							echo $log;
							echo '</div>';
						}

					} else {
						// Set marker div that will be fildered by ajax request
						echo '<div class="ajax-request-error"></div>';

						// output log in the div
						echo '<div class="ajax-error-log">';
						echo "Can't open file: " . $import_file . "</ br>";
						echo '</div>';
					}
				}

			} else {
				// Set marker div that will be fildered by ajax request
				echo '<div class="ajax-request-error"></div>';

				// output log in the div
				echo '<div class="ajax-error-log">';
				echo "Failed to load: " . $class_wp_import . "</ br>";
				echo '</div>';
			}
		}

		/**
		 * ----------------------------------------------------------------------
		 * Demo Content: Full
		 */

		if ( $_GET['importcontent'] == 'alldemocontent' ) {
			$import_path = $theme_dir . 'includes/installer/';

			// 1: Assign menus
			$locations = get_nav_menu_locations();

			$term_primary = get_term_by('name', 'Header menu', 'nav_menu');
			$menu_id_primary = $term_primary->term_id;

			$term_footer = get_term_by('name', 'Footer menu', 'nav_menu');
			$menu_id_footer = $term_footer->term_id;

			// check if 'primary' location has no menu assigned
			if( !has_nav_menu('primary') && isset($menu_id_primary) ) {
				// Attach saved before menu id to 'topbar' location
				$locations = get_nav_menu_locations();
				$locations['primary'] = $menu_id_primary;
				set_theme_mod('nav_menu_locations', $locations);
			}

			// check if 'footer' location has no menu assigned
			if( !has_nav_menu('footer') && isset($menu_id_footer) ) {
				// Attach saved before menu id to 'topbar' location
				$locations = get_nav_menu_locations();
				$locations['footer'] = $menu_id_footer;
				set_theme_mod('nav_menu_locations', $locations);
			}

			update_option('blogdescription', '');

			// 3: Use a static front page
			$home_page = get_page_by_title( WHITELAB_HOME_TITLE );
			update_option( 'page_on_front', $home_page->ID );
			update_option( 'show_on_front', 'page' );
			set_theme_mod( 'whitelab_footer_style', 'minimal' );

			// 4: Activate Whitelab directory theme
			global $wpdb;
			$main_settings = get_option( 'db_main_settings');

			$main_settings['db_theme_id'] = 'db_theme';
			$main_settings['db_theme_path'] = get_template_directory().'/directory-template/';
			$main_settings['db_theme_url'] = get_template_directory_uri().'/directory-template/';

			update_option( 'db_main_settings', $main_settings );

			// Set template for search page
			$directory_builder_search = get_page_by_title( 'Directory builder search' );
			update_post_meta($directory_builder_search->ID, '_wp_page_template',  'template-listing_search.php');

			// Set sticky listings
			$sticky_listings = get_option('db_sticky_listings');
			if ( !isset($sticky_listings) || $sticky_listings == '' ) {
				$sticky_listings = array();
			}
			$sticky_listings[] = 91;
			$sticky_listings[] = 118;
			$sticky_listings[] = 101;
			$sticky_listings[] = 269;
			update_option('db_sticky_listings', $sticky_listings);

			// Import packages
			$wpdb->query(esc_sql("TRUNCATE TABLE " . $wpdb->prefix . "directory_packages"));
			$wpdb->query("INSERT INTO `" . $wpdb->prefix . "directory_packages` (`ID`, `package_name`, `package_settings`) VALUES
						(1, 'Basic', '{\"fee_label\":\"Basic\",\"fee_amount\":\"0\",\"listing_run_type\":\"days\",\"listing_run_days\":\"365\",\"image_amount\":\"1\",\"listing_sticky\":false,\"apply_categories\":[\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\"],\"fee_description\":\"The best choice if you are ok with the basic features.\",\"listing_status\":\"draft\",\"listing_popular\":false,\"package_img\":\"http://dev.cohhe.com/themes/smartwriter/wp-content/uploads/2016/11/home.png\"}'),
						(2, 'Ultimate', '{\"fee_label\":\"Ultimate\",\"fee_amount\":\"39\",\"listing_run_type\":\"days\",\"listing_run_days\":\"365\",\"image_amount\":\"5\",\"listing_sticky\":true,\"apply_categories\":[\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\"],\"fee_description\":\"This is the ultimate package, all you will ever need.\",\"listing_status\":\"draft\",\"listing_popular\":true,\"package_img\":\"http://dev.cohhe.com/themes/smartwriter/wp-content/uploads/2016/11/house1.png\"}'),
						(3, 'Premium', '{\"fee_label\":\"Premium\",\"fee_amount\":\"19\",\"listing_run_type\":\"days\",\"listing_run_days\":\"365\",\"image_amount\":\"3\",\"listing_sticky\":false,\"apply_categories\":[\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\"],\"fee_description\":\"This is kind of between Basic and Ultimate packages.\",\"listing_status\":\"draft\",\"listing_popular\":false,\"package_img\":\"http://dev.cohhe.com/themes/smartwriter/wp-content/uploads/2016/11/home2.png\"}')");

			// 5: Import widgets
			$files_with_widgets_to_import = array();
			$files_with_widgets_to_import[] = $import_path . 'widgets.wie';

			$widgets = get_option('sidebars_widgets');
			$widgets['whitelab-sidebar-3'] = array();
			update_option('sidebars_widgets', $widgets);

			foreach ($files_with_widgets_to_import as $file) {
				pvt_import_data( $file );
			}

			// 6: Fix "Popular cities" issue
			$replaced_content = 'New York:222
London:224
New Delhi:226
San Francisco:494
Paris:232
Madrid:229
Rome:234
Ottawa:493';

			// 7: Set categories for the header
			set_theme_mod('whitelab_search_categories', array( '0' => '11', '1' => '13', '2' => '14', '3' => '15', '4' => '17' ));
			$cat_meta11 = get_option( "listing_category_11");
			$cat_meta11['tag-category-icon'] = 'wl-beauty';
			$cat_meta11['tag-category-color'] = '#f25f5c';
			update_option( "listing_category_11", $cat_meta11);

			$cat_meta13 = get_option( "listing_category_13");
			$cat_meta13['tag-category-icon'] = 'wl-catering';
			$cat_meta13['tag-category-color'] = '#00a9e8';
			update_option( "listing_category_13", $cat_meta13);

			$cat_meta14 = get_option( "listing_category_14");
			$cat_meta14['tag-category-icon'] = 'wl-finances';
			$cat_meta14['tag-category-color'] = '#00a9e8';
			update_option( "listing_category_14", $cat_meta14);

			$cat_meta15 = get_option( "listing_category_15");
			$cat_meta15['tag-category-icon'] = 'wl-health';
			$cat_meta15['tag-category-color'] = '#ffe066';
			update_option( "listing_category_15", $cat_meta15);

			$cat_meta17 = get_option( "listing_category_17");
			$cat_meta17['tag-category-icon'] = 'wl-plants';
			$cat_meta17['tag-category-color'] = '';
			update_option( "listing_category_17", $cat_meta17);

			$wpdb->query("UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, '{popular_cities}', '".$replaced_content."')");

		} // if $_GET['importcontent']

	} // is isset($_GET['importcontent'])
}

/**
* ----------------------------------------------------------------------
* Start a theme tour
*/

if ( is_admin() && isset($_GET['theme_tour'] ) && $pagenow == "themes.php" ) {
	// Register the pointer styles and scripts
	add_action( 'admin_enqueue_scripts', 'enqueue_scripts' );

	// Add pointer javascript
	add_action( 'admin_print_footer_scripts', 'add_pointer_scripts' );

	// enqueue javascripts and styles
	function enqueue_scripts()
	{
		wp_enqueue_style( 'wp-pointer' );
		wp_enqueue_script( 'wp-pointer' );
	}

	// Add the pointer javascript
	function add_pointer_scripts()
	{
		$pointer_content = '<h3>We use a theme options</h3>';
		$pointer_content .= '<p>Most of theme options are available for customization in theme options page.</p>';
	?>
		<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			$('#menu-appearance a[href="themes.php?page=themeoptions"]').pointer({
				// pointer_id: 'customizer_menu_link',
				content: '<?php echo $pointer_content; ?>',
				position: {
					 edge: 'left', //top, bottom, left, right
					 align: 'middle' //top, bottom, left, right, middle
				 },
				buttons: function( event, t ) {

					var $buttonClose = jQuery('<a class="button-secondary" style="margin-right:10px;" href="#">End Tour</a>');
					$buttonClose.bind( 'click.pointer', function() {

						t.element.pointer('close');
					});

					var buttons = $('<div class="tiptour-buttons">');
					buttons.append($buttonClose);
					buttons.append('<a class="button-primary" style="margin-right:10px;" href="<?php echo admin_url('themes.php?page=themeoptions#first-time-visit'); ?>">Go to Theme Options</a>');
					return buttons;
				},

				close: function() {
					// Once the close button is hit
					$.post( ajaxurl, {
						pointer: 'customizer_menu_link',
						action: 'dismiss-wp-pointer'
					});
				}
			}).pointer('open');

			$(".vhman-message.quick-setup .step-tour").addClass("step-completed");
		});
		//]]>
		</script>
	<?php
	}
	update_option('whitelab_hide_quicksetup', true ); // set option to not show quick setup block anymore
}

/* Hide quick tour message block */
if ( is_admin() && isset($_GET['hide_quicksetup'] ) && $pagenow == "themes.php" ) {
	update_option('whitelab_hide_quicksetup', true ); // set option to not show quick setup block anymore
}