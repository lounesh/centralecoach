=== Functionality for directory theme ===
Contributors: cohhe
Tags: directory, ecommerce
Requires at least: 4.2
Tested up to: 4.7.3
Stable tag: 1.3.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

directory functionality plugin adds additional functions to directory theme.

== Description ==

directory functionality plugin adds additional functions to directory theme.


== Installation ==

Installing "directory functionality" can be done either by searching for "directory functionality" via the "Plugins > Add New" screen in your WordPress dashboard, or by using the following steps:

1. Download the plugin via WordPress.org
1. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==


== Frequently Asked Questions ==


== Changelog ==

= 1.3.8 =
* Added a new module called "Listings by category"

= 1.3.7 =
* Fixed featured listing issue with WPML plugin
* Images at post grid are now clickable
* Updated language files

= 1.3.6 =
* Improved the favorite listing query

= 1.3.5 =
* A new Visual Composer module called "Listing search form"
* Added a new option for "Featured listings" module, to randomly show featured listings
* Added captcha

= 1.3.4 =
* Fixed error which caused issue with category icons

= 1.3.3 =
* Added a category module to Visual Composer

= 1.3.2 =
* Notification emails
* External url for cities module
* PHP7 compatibility issues
* Trial package support
* Load scripts only where they're needed
* Fixed issue with gallery and improved gallery module

= 1.3.1 =
* Made compatible with SSL

= 1.3.0 =
* Improved cities module

= 1.2.9 =
* Demo import file
* Gallery responsiveness

= 1.2.8 =
* Fixed gallery margins
* Improved claim listing functionality
* Bugfixes

= 1.2.7 =
* Listing like/dislike icons added and functionality improved
* Featured listing custom field styling improvements

= 1.2.6 =
* Updated language file
* Fixed issue with free listing modal
* Allow to renew listing is it's completed

= 1.2.5 =
* Allow to add icons to custom fields
* Fixed default category when listing is created

= 1.2.4 =
* Fixed error with amenities
* Fixed issue which prevented street names from being added to the map
* Fixed "Set address button"

= 1.2.2 =
* Fixed issue with custom fields at directory builder
* Set and configure header categories after demo import

= 1.2 =
* Checkout issues

= 1.1 =
* Bugfixes

= 1.0 =
* 2015-08-04
* Initial release

== Upgrade Notice ==

= 1.0 =
* 2015-08-04
* Initial release